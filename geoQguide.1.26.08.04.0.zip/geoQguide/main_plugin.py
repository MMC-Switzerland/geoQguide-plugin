import os
from.settings_manager import SettingsManager
_HERE=os.path.dirname(os.path.abspath(__file__))
_ICON_PATH=os.path.join(_HERE,'ToolbarIcon.svg')
class GeoQguidePlugin:
	def __init__(A,iface):A.iface=iface;A._action=None;A._in_toolbar=False;A._runner=None;A._api_client=None;A.settings=SettingsManager();A.settings.write_defaults();from.audit import AuditLog as B;A.audit=B(settings_manager=A.settings)
	def initGui(A):from qgis.PyQt.QtWidgets import QAction as C;from qgis.PyQt.QtGui import QIcon;A._action=C(QIcon(_ICON_PATH),'geoQguide',A.iface.mainWindow());A._action.setToolTip('geoQguide');A._action.triggered.connect(A.run);A.iface.pluginMenu().addAction(A._action);A.apply_access_points();from.version_check import schedule_check as D;import configparser as E,os;B=E.ConfigParser();B.read(os.path.join(_HERE,'metadata.txt'));F=B.get('general','version',fallback='0');D(F,A.iface);A.audit.start()
	def apply_access_points(A):
		if A._action is None:return
		B=bool(A.settings.read().show_toolbar_button)
		if B and not A._in_toolbar:A.iface.addToolBarIcon(A._action)
		elif not B and A._in_toolbar:A.iface.removeToolBarIcon(A._action)
		A._in_toolbar=B
	def unload(A):
		A.audit.shutdown()
		if A._action is not None:
			A.iface.pluginMenu().removeAction(A._action)
			if A._in_toolbar:A.iface.removeToolBarIcon(A._action)
		A._in_toolbar=False;A._action=None;A._runner=None
	def _get_runner(A):
		if A._runner is None:from.runner import ScriptRunner as B;A._runner=B(bundle_path=os.path.join(_HERE,'bundle.tar.gz.enc'),api_client=A._api_client,audit=A.audit)
		return A._runner
	def _get_api_client(A):
		if A._api_client is None:
			import traceback as C
			try:from.api_client import GeoQGuideApiClient as D;E=A.settings.read();A._api_client=D(base_url=E.api_base_url)
			except Exception:
				B=C.format_exc();print(f"[geoQguide] FATAL — could not initialise API client:\n{B}")
				try:from qgis.core import QgsMessageLog as F,Qgis;F.logMessage(f"FATAL — could not initialise API client:\n{B}",'geoQguide',Qgis.Critical)
				except Exception:pass
				raise
		return A._api_client
	def run(A):
		import traceback as D;B=None;C=''
		try:B=A._get_api_client()
		except Exception:C=D.format_exc()
		E=None
		try:E=A._get_runner()
		except Exception:
			if not C:C=D.format_exc()
		if B is not None:
			try:from.audit import ApiAuditTransport as F;A.audit.set_transport(F(B))
			except Exception:pass
		from.launcher_dialog import launch as G;G(runner=E,settings_manager=A.settings,api_client=B,api_client_error=C,audit=A.audit,on_settings_saved=A.apply_access_points)