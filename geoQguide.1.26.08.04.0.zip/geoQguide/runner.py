import os,builtins,uuid
from.bundle_loader import BundleLoader
class ScriptRunner:
	def __init__(A,local_dir='',bundle_path='',api_client=None,audit=None):
		C=bundle_path;B=audit;A._bundle_path=C;A._api_client=api_client;A._loader=BundleLoader(C)
		if B is None:from.audit import NullAuditLog as D;B=D()
		A._audit=B
	def run(A,script_name,globals_dict=None):
		E=globals_dict;D=script_name;B={}if E is None else dict(E);B.setdefault('run_script',A.run);F=B.get('gqg_run_id')or uuid.uuid4().hex;B['gqg_run_id']=F;B['gqg_audit']=A._audit.emitter(_base_name(D),F);G=True
		if G:A._download_bundle()
		A._loader.ensure_loaded();B.setdefault('scripts',A._loader._scripts);C=A._resolve_bundle_name(D);print(f"[ScriptRunner] Priority 2 — bundle: {C!r}");B.setdefault('__file__',C);A._loader.run_script(C,B)
	def _resolve_bundle_name(A,script_name):
		B=script_name
		for C in A._bundle_candidates(B):
			if A._loader.has_script(C):return C
		raise KeyError(f"[ScriptRunner] {B!r} not found in bundle. Tried: {A._bundle_candidates(B)}")
	@staticmethod
	def _bundle_candidates(script_name):A=script_name;B=_base_name(A);return[A,B+'.py.min',B+'.py']
	def _bundle_needs_update(A):
		if not os.path.isfile(A._bundle_path):print('[ScriptRunner] Bundle absent — will download.');return True
		return False
	def _download_bundle(A):
		from.api_client.geo_q_guide_api_client.api.plugin_code_bundle import get_plugin_bundle as D,get_plugin_bundle_key as E;print('[ScriptRunner] Fetching bundle key from API …');B=A._api_client.call(E.sync_detailed)
		if B.status_code!=200:raise RuntimeError(f"[ScriptRunner] Bundle key fetch failed: HTTP {B.status_code}")
		A._loader.set_key(B.content);print(f"[ScriptRunner] Downloading bundle via API → {A._bundle_path!r} …");C=A._api_client.call(D.sync_detailed)
		if C.status_code!=200:raise RuntimeError(f"[ScriptRunner] Bundle download failed: HTTP {C.status_code}")
		with open(A._bundle_path,'wb')as F:F.write(C.content)
		A._loader._loaded=False;A._loader._scripts.clear();print('[ScriptRunner] Bundle downloaded successfully.')
def _base_name(script_name):
	A=script_name
	for B in('.min','.py'):
		if A.endswith(B):A=A[:-len(B)]
	return A