from __future__ import annotations
import os,tempfile
from dataclasses import dataclass
from typing import Optional
from qgis.core import QgsSettings
PLUGIN_KEY='plugins/geoQguide'
@dataclass
class PluginSettings:output_dir:str='';local_override_dir:str='';api_base_url:str='https://geoqguide-api.borsafotovoltaica.it/';open_topo_api_key:str='';docx_template:str='';docx_template_url:str=''
class SettingsManager:
	_K_OUTPUT_DIR=f"{PLUGIN_KEY}/output_dir";_K_LOCAL_OVERRIDE_DIR=f"{PLUGIN_KEY}/local_override_dir";_K_OPEN_TOPO_API_KEY=f"{PLUGIN_KEY}/open_topo_api_key";_K_DOCX_TEMPLATE=f"{PLUGIN_KEY}/docx_template";_K_API_BASE_URL=f"{PLUGIN_KEY}/api_base_url";_K_DOCX_TEMPLATE_URL=f"{PLUGIN_KEY}/docx_template_url";_DEFAULTS=PluginSettings(output_dir=os.path.join(os.path.expanduser('~'),'Documents','geoQguide'),local_override_dir='',api_base_url='https://geoqguide-api.borsafotovoltaica.it/',open_topo_api_key='',docx_template='',docx_template_url='');_WRITE_DEFAULTS_KEYS=frozenset({'output_dir'})
	def read(A):
		B=QgsSettings();D={'output_dir':B.value(A._K_OUTPUT_DIR,None),'local_override_dir':B.value(A._K_LOCAL_OVERRIDE_DIR,None),'api_base_url':B.value(A._K_API_BASE_URL,None),'open_topo_api_key':B.value(A._K_OPEN_TOPO_API_KEY,None),'docx_template':B.value(A._K_DOCX_TEMPLATE,None),'docx_template_url':B.value(A._K_DOCX_TEMPLATE_URL,None)}
		def C(key):
			B=D.get(key)
			if B is None or isinstance(B,str)and B=='':return getattr(A._DEFAULTS,key)
			return str(B)
		return PluginSettings(output_dir=C('output_dir'),local_override_dir=C('local_override_dir'),api_base_url=C('api_base_url'),open_topo_api_key=C('open_topo_api_key'),docx_template=C('docx_template'),docx_template_url=C('docx_template_url'))
	def write(A,settings):
		B=settings;C=QgsSettings();C.setValue(A._K_OUTPUT_DIR,B.output_dir);C.setValue(A._K_API_BASE_URL,B.api_base_url);C.setValue(A._K_OPEN_TOPO_API_KEY,B.open_topo_api_key);C.setValue(A._K_DOCX_TEMPLATE,B.docx_template);C.setValue(A._K_DOCX_TEMPLATE_URL,B.docx_template_url)
		if B.local_override_dir:C.setValue(A._K_LOCAL_OVERRIDE_DIR,B.local_override_dir)
		else:C.remove(A._K_LOCAL_OVERRIDE_DIR)
	def write_defaults(A):
		B=QgsSettings();C='geoQguide'
		for D in(f"{C}/output_dir",f"{C}/local_override_dir"):
			if B.value(D,None)is not None:B.remove(D)
		if'output_dir'in A._WRITE_DEFAULTS_KEYS:
			E=B.value(A._K_OUTPUT_DIR,None)
			if not E:B.setValue(A._K_OUTPUT_DIR,A._DEFAULTS.output_dir);print(f"[SettingsManager] write_defaults: set output_dir = {A._DEFAULTS.output_dir!r}")
			else:print(f"[SettingsManager] write_defaults: output_dir already set = {E!r}")
		print(f"[SettingsManager] write_defaults: settings file = {B.fileName()}")
	def get_temp_dir(B):A=os.path.join(tempfile.gettempdir(),'geoQguide');os.makedirs(A,exist_ok=True);return A