@echo off
setlocal
cd /d "%~dp0"

echo Downloading swagger.json...
curl -k https://localhost:7294/swagger/v1/swagger.json -o swagger.json
if %ERRORLEVEL% neq 0 (
    echo ERROR: Failed to download swagger.json
    exit /b 1
)

echo Generating client...
openapi-python-client generate --path swagger.json --overwrite
if %ERRORLEVEL% neq 0 (
    echo ERROR: openapi-python-client failed
    exit /b 1
)

echo Updating geo_q_guide_api_client...
if exist "geo_q_guide_api_client" (
    rmdir /s /q "geo_q_guide_api_client"
)
move "geo-q-guide-api-client\geo_q_guide_api_client" "geo_q_guide_api_client"
rmdir /s /q "geo-q-guide-api-client"

echo Done.
endlocal
