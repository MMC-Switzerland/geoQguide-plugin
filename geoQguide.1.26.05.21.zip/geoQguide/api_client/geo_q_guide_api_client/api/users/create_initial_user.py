from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_initial_user_request import CreateInitialUserRequest
from ...models.create_initial_user_response import CreateInitialUserResponse
from ...types import Response


def _get_kwargs(
    *,
    body: CreateInitialUserRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/users/create-initial",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, CreateInitialUserResponse]]:
    if response.status_code == 200:
        response_200 = CreateInitialUserResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, CreateInitialUserResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateInitialUserRequest,
) -> Response[Union[Any, CreateInitialUserResponse]]:
    """Create an initial user in the system using ASP.NET Core Identity

     Creates a new user with the specified email, first name, last name, and password. If a user with the
    same email already exists, returns the existing user's ID.

    Args:
        body (CreateInitialUserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CreateInitialUserResponse]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateInitialUserRequest,
) -> Optional[Union[Any, CreateInitialUserResponse]]:
    """Create an initial user in the system using ASP.NET Core Identity

     Creates a new user with the specified email, first name, last name, and password. If a user with the
    same email already exists, returns the existing user's ID.

    Args:
        body (CreateInitialUserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, CreateInitialUserResponse]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateInitialUserRequest,
) -> Response[Union[Any, CreateInitialUserResponse]]:
    """Create an initial user in the system using ASP.NET Core Identity

     Creates a new user with the specified email, first name, last name, and password. If a user with the
    same email already exists, returns the existing user's ID.

    Args:
        body (CreateInitialUserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, CreateInitialUserResponse]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: CreateInitialUserRequest,
) -> Optional[Union[Any, CreateInitialUserResponse]]:
    """Create an initial user in the system using ASP.NET Core Identity

     Creates a new user with the specified email, first name, last name, and password. If a user with the
    same email already exists, returns the existing user's ID.

    Args:
        body (CreateInitialUserRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, CreateInitialUserResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
