from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

T = TypeVar("T", bound="CreateInitialUserResponse")


@_attrs_define
class CreateInitialUserResponse:
    """
    Attributes:
        user_id (int):
        message (Union[None, str]):
    """

    user_id: int
    message: Union[None, str]

    def to_dict(self) -> dict[str, Any]:
        user_id = self.user_id

        message: Union[None, str]
        message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "userId": user_id,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_id = d.pop("userId")

        def _parse_message(data: object) -> Union[None, str]:
            if data is None:
                return data
            return cast(Union[None, str], data)

        message = _parse_message(d.pop("message"))

        create_initial_user_response = cls(
            user_id=user_id,
            message=message,
        )

        return create_initial_user_response
