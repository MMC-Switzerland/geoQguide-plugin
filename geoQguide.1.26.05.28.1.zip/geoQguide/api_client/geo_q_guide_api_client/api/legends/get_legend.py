from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.legend_model import LegendModel
from ...types import UNSET, Response


def _get_kwargs(
    *,
    data_source_uri: str,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["DataSourceUri"] = data_source_uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/legend",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[LegendModel, str]]:
    if response.status_code == 200:
        response_200 = LegendModel.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(str, response.json())
        return response_400

    if response.status_code == 404:
        response_404 = cast(str, response.json())
        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[LegendModel, str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    data_source_uri: str,
) -> Response[Union[LegendModel, str]]:
    """Get legend by data source URI

     Retrieves a legend for the specified QGIS data source URI

    Args:
        data_source_uri (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[LegendModel, str]]
    """

    kwargs = _get_kwargs(
        data_source_uri=data_source_uri,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    data_source_uri: str,
) -> Optional[Union[LegendModel, str]]:
    """Get legend by data source URI

     Retrieves a legend for the specified QGIS data source URI

    Args:
        data_source_uri (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[LegendModel, str]
    """

    return sync_detailed(
        client=client,
        data_source_uri=data_source_uri,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    data_source_uri: str,
) -> Response[Union[LegendModel, str]]:
    """Get legend by data source URI

     Retrieves a legend for the specified QGIS data source URI

    Args:
        data_source_uri (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[LegendModel, str]]
    """

    kwargs = _get_kwargs(
        data_source_uri=data_source_uri,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    data_source_uri: str,
) -> Optional[Union[LegendModel, str]]:
    """Get legend by data source URI

     Retrieves a legend for the specified QGIS data source URI

    Args:
        data_source_uri (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[LegendModel, str]
    """

    return (
        await asyncio_detailed(
            client=client,
            data_source_uri=data_source_uri,
        )
    ).parsed
