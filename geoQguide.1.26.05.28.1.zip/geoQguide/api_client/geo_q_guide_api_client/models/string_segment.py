from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="StringSegment")


@_attrs_define
class StringSegment:
    """
    Attributes:
        buffer (Union[None, Unset, str]):
        offset (Union[Unset, int]):
        length (Union[Unset, int]):
        value (Union[None, Unset, str]):
        has_value (Union[Unset, bool]):
    """

    buffer: Union[None, Unset, str] = UNSET
    offset: Union[Unset, int] = UNSET
    length: Union[Unset, int] = UNSET
    value: Union[None, Unset, str] = UNSET
    has_value: Union[Unset, bool] = UNSET

    def to_dict(self) -> dict[str, Any]:
        buffer: Union[None, Unset, str]
        if isinstance(self.buffer, Unset):
            buffer = UNSET
        else:
            buffer = self.buffer

        offset = self.offset

        length = self.length

        value: Union[None, Unset, str]
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        has_value = self.has_value

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if buffer is not UNSET:
            field_dict["buffer"] = buffer
        if offset is not UNSET:
            field_dict["offset"] = offset
        if length is not UNSET:
            field_dict["length"] = length
        if value is not UNSET:
            field_dict["value"] = value
        if has_value is not UNSET:
            field_dict["hasValue"] = has_value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_buffer(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        buffer = _parse_buffer(d.pop("buffer", UNSET))

        offset = d.pop("offset", UNSET)

        length = d.pop("length", UNSET)

        def _parse_value(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        value = _parse_value(d.pop("value", UNSET))

        has_value = d.pop("hasValue", UNSET)

        string_segment = cls(
            buffer=buffer,
            offset=offset,
            length=length,
            value=value,
            has_value=has_value,
        )

        return string_segment
