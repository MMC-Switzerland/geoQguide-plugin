import datetime
from collections.abc import Mapping
from io import BytesIO
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, File, FileTypes, Unset

if TYPE_CHECKING:
    from ..models.entity_tag_header_value import EntityTagHeaderValue


T = TypeVar("T", bound="FileStreamHttpResult")


@_attrs_define
class FileStreamHttpResult:
    """
    Attributes:
        content_type (Union[None, Unset, str]):
        file_download_name (Union[None, Unset, str]):
        last_modified (Union[None, Unset, datetime.datetime]):
        entity_tag (Union[Unset, EntityTagHeaderValue]):
        enable_range_processing (Union[Unset, bool]):
        file_length (Union[None, Unset, int]):
        file_stream (Union[File, None, Unset]):
    """

    content_type: Union[None, Unset, str] = UNSET
    file_download_name: Union[None, Unset, str] = UNSET
    last_modified: Union[None, Unset, datetime.datetime] = UNSET
    entity_tag: Union[Unset, "EntityTagHeaderValue"] = UNSET
    enable_range_processing: Union[Unset, bool] = UNSET
    file_length: Union[None, Unset, int] = UNSET
    file_stream: Union[File, None, Unset] = UNSET

    def to_dict(self) -> dict[str, Any]:
        content_type: Union[None, Unset, str]
        if isinstance(self.content_type, Unset):
            content_type = UNSET
        else:
            content_type = self.content_type

        file_download_name: Union[None, Unset, str]
        if isinstance(self.file_download_name, Unset):
            file_download_name = UNSET
        else:
            file_download_name = self.file_download_name

        last_modified: Union[None, Unset, str]
        if isinstance(self.last_modified, Unset):
            last_modified = UNSET
        elif isinstance(self.last_modified, datetime.datetime):
            last_modified = self.last_modified.isoformat()
        else:
            last_modified = self.last_modified

        entity_tag: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.entity_tag, Unset):
            entity_tag = self.entity_tag.to_dict()

        enable_range_processing = self.enable_range_processing

        file_length: Union[None, Unset, int]
        if isinstance(self.file_length, Unset):
            file_length = UNSET
        else:
            file_length = self.file_length

        file_stream: Union[FileTypes, None, Unset]
        if isinstance(self.file_stream, Unset):
            file_stream = UNSET
        elif isinstance(self.file_stream, File):
            file_stream = self.file_stream.to_tuple()

        else:
            file_stream = self.file_stream

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if content_type is not UNSET:
            field_dict["contentType"] = content_type
        if file_download_name is not UNSET:
            field_dict["fileDownloadName"] = file_download_name
        if last_modified is not UNSET:
            field_dict["lastModified"] = last_modified
        if entity_tag is not UNSET:
            field_dict["entityTag"] = entity_tag
        if enable_range_processing is not UNSET:
            field_dict["enableRangeProcessing"] = enable_range_processing
        if file_length is not UNSET:
            field_dict["fileLength"] = file_length
        if file_stream is not UNSET:
            field_dict["fileStream"] = file_stream

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.entity_tag_header_value import EntityTagHeaderValue

        d = dict(src_dict)

        def _parse_content_type(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        content_type = _parse_content_type(d.pop("contentType", UNSET))

        def _parse_file_download_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        file_download_name = _parse_file_download_name(d.pop("fileDownloadName", UNSET))

        def _parse_last_modified(data: object) -> Union[None, Unset, datetime.datetime]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_modified_type_0 = isoparse(data)

                return last_modified_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, datetime.datetime], data)

        last_modified = _parse_last_modified(d.pop("lastModified", UNSET))

        _entity_tag = d.pop("entityTag", UNSET)
        entity_tag: Union[Unset, EntityTagHeaderValue]
        if isinstance(_entity_tag, Unset):
            entity_tag = UNSET
        else:
            entity_tag = EntityTagHeaderValue.from_dict(_entity_tag)

        enable_range_processing = d.pop("enableRangeProcessing", UNSET)

        def _parse_file_length(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        file_length = _parse_file_length(d.pop("fileLength", UNSET))

        def _parse_file_stream(data: object) -> Union[File, None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, bytes):
                    raise TypeError()
                file_stream_type_0 = File(payload=BytesIO(data))

                return file_stream_type_0
            except:  # noqa: E722
                pass
            return cast(Union[File, None, Unset], data)

        file_stream = _parse_file_stream(d.pop("fileStream", UNSET))

        file_stream_http_result = cls(
            content_type=content_type,
            file_download_name=file_download_name,
            last_modified=last_modified,
            entity_tag=entity_tag,
            enable_range_processing=enable_range_processing,
            file_length=file_length,
            file_stream=file_stream,
        )

        return file_stream_http_result
