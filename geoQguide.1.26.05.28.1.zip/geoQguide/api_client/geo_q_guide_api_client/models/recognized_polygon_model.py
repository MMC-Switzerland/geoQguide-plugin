from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.geo_json_polygon import GeoJsonPolygon


T = TypeVar("T", bound="RecognizedPolygonModel")


@_attrs_define
class RecognizedPolygonModel:
    """
    Attributes:
        legend_item_id (Union[Unset, int]):
        polygon (Union[Unset, GeoJsonPolygon]):
    """

    legend_item_id: Union[Unset, int] = UNSET
    polygon: Union[Unset, "GeoJsonPolygon"] = UNSET

    def to_dict(self) -> dict[str, Any]:
        legend_item_id = self.legend_item_id

        polygon: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.polygon, Unset):
            polygon = self.polygon.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if legend_item_id is not UNSET:
            field_dict["legendItemId"] = legend_item_id
        if polygon is not UNSET:
            field_dict["polygon"] = polygon

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.geo_json_polygon import GeoJsonPolygon

        d = dict(src_dict)
        legend_item_id = d.pop("legendItemId", UNSET)

        _polygon = d.pop("polygon", UNSET)
        polygon: Union[Unset, GeoJsonPolygon]
        if isinstance(_polygon, Unset):
            polygon = UNSET
        else:
            polygon = GeoJsonPolygon.from_dict(_polygon)

        recognized_polygon_model = cls(
            legend_item_id=legend_item_id,
            polygon=polygon,
        )

        return recognized_polygon_model
