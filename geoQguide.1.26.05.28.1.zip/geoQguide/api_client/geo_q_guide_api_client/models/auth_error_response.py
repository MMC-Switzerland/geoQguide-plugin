from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..models.auth_error_code import AuthErrorCode
from ..types import UNSET, Unset

T = TypeVar("T", bound="AuthErrorResponse")


@_attrs_define
class AuthErrorResponse:
    """
    Attributes:
        error_code (Union[Unset, AuthErrorCode]):
        message (Union[None, Unset, str]):
    """

    error_code: Union[Unset, AuthErrorCode] = UNSET
    message: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        error_code: Union[Unset, int] = UNSET
        if not isinstance(self.error_code, Unset):
            error_code = self.error_code.value

        message: Union[None, Unset, str]
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if error_code is not UNSET:
            field_dict["errorCode"] = error_code
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _error_code = d.pop("errorCode", UNSET)
        error_code: Union[Unset, AuthErrorCode]
        if isinstance(_error_code, Unset):
            error_code = UNSET
        else:
            error_code = AuthErrorCode(_error_code)

        def _parse_message(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        message = _parse_message(d.pop("message", UNSET))

        auth_error_response = cls(
            error_code=error_code,
            message=message,
        )

        return auth_error_response
