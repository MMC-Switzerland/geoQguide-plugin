from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.directory_contents_dto import DirectoryContentsDto


T = TypeVar("T", bound="ListDirectoryContentsResponse")


@_attrs_define
class ListDirectoryContentsResponse:
    """
    Attributes:
        directories (Union[None, list['DirectoryContentsDto']]):
        message (Union[None, str]):
    """

    directories: Union[None, list["DirectoryContentsDto"]]
    message: Union[None, str]

    def to_dict(self) -> dict[str, Any]:
        directories: Union[None, list[dict[str, Any]]]
        if isinstance(self.directories, list):
            directories = []
            for directories_type_0_item_data in self.directories:
                directories_type_0_item = directories_type_0_item_data.to_dict()
                directories.append(directories_type_0_item)

        else:
            directories = self.directories

        message: Union[None, str]
        message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "directories": directories,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.directory_contents_dto import DirectoryContentsDto

        d = dict(src_dict)

        def _parse_directories(data: object) -> Union[None, list["DirectoryContentsDto"]]:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                directories_type_0 = []
                _directories_type_0 = data
                for directories_type_0_item_data in _directories_type_0:
                    directories_type_0_item = DirectoryContentsDto.from_dict(directories_type_0_item_data)

                    directories_type_0.append(directories_type_0_item)

                return directories_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, list["DirectoryContentsDto"]], data)

        directories = _parse_directories(d.pop("directories"))

        def _parse_message(data: object) -> Union[None, str]:
            if data is None:
                return data
            return cast(Union[None, str], data)

        message = _parse_message(d.pop("message"))

        list_directory_contents_response = cls(
            directories=directories,
            message=message,
        )

        return list_directory_contents_response
