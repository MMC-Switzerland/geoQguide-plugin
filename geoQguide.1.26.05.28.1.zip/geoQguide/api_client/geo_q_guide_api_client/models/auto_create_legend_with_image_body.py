from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import File

T = TypeVar("T", bound="AutoCreateLegendWithImageBody")


@_attrs_define
class AutoCreateLegendWithImageBody:
    """
    Attributes:
        data_source_uri (str): The QGIS data source URI of the layer Example: contextualWMSLegend=0&crs=EPSG:32632&dpiMo
            de=7&featureCount=10&format=image/png&layers=ulter_cont_unesco&styles&tilePixelRatio=0&url=http://www502.regione
            .toscana.it/wmsraster/com.rt.wms.RTmap/wms?map%3Dwmspiapae%26map_resolution%3D91.
        sensitivity (int): Sensitivity parameter for clustering (1-10) Example: 5.
        tile_size (int): Size of tiles for analysis (15-60 pixels) Example: 30.
        map_image (File): Map image file (PNG, JPEG, etc.)
    """

    data_source_uri: str
    sensitivity: int
    tile_size: int
    map_image: File
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data_source_uri = self.data_source_uri

        sensitivity = self.sensitivity

        tile_size = self.tile_size

        map_image = self.map_image.to_tuple()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dataSourceUri": data_source_uri,
                "sensitivity": sensitivity,
                "tileSize": tile_size,
                "mapImage": map_image,
            }
        )

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("dataSourceUri", (None, str(self.data_source_uri).encode(), "text/plain")))

        files.append(("sensitivity", (None, str(self.sensitivity).encode(), "text/plain")))

        files.append(("tileSize", (None, str(self.tile_size).encode(), "text/plain")))

        files.append(("mapImage", self.map_image.to_tuple()))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        data_source_uri = d.pop("dataSourceUri")

        sensitivity = d.pop("sensitivity")

        tile_size = d.pop("tileSize")

        map_image = File(payload=BytesIO(d.pop("mapImage")))

        auto_create_legend_with_image_body = cls(
            data_source_uri=data_source_uri,
            sensitivity=sensitivity,
            tile_size=tile_size,
            map_image=map_image,
        )

        auto_create_legend_with_image_body.additional_properties = d
        return auto_create_legend_with_image_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
