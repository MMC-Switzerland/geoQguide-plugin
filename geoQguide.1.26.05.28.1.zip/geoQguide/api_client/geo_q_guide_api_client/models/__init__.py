"""Contains all the data models used in inputs/outputs"""

from .auth_error_code import AuthErrorCode
from .auth_error_response import AuthErrorResponse
from .auto_create_legend_with_image_body import AutoCreateLegendWithImageBody
from .directory_contents_dto import DirectoryContentsDto
from .ensure_directories_request import EnsureDirectoriesRequest
from .ensure_directories_response import EnsureDirectoriesResponse
from .entity_tag_header_value import EntityTagHeaderValue
from .example_request import ExampleRequest
from .file_stream_http_result import FileStreamHttpResult
from .geo_json_polygon import GeoJsonPolygon
from .http_validation_problem_details import HttpValidationProblemDetails
from .http_validation_problem_details_errors_type_0 import HttpValidationProblemDetailsErrorsType0
from .legend_auto_create_request import LegendAutoCreateRequest
from .legend_item_model import LegendItemModel
from .legend_model import LegendModel
from .list_directory_contents_request import ListDirectoryContentsRequest
from .list_directory_contents_response import ListDirectoryContentsResponse
from .login_request import LoginRequest
from .login_response import LoginResponse
from .logout_request import LogoutRequest
from .process_recognition_with_image_body import ProcessRecognitionWithImageBody
from .qgis_extent_dto import QgisExtentDto
from .recognition_request import RecognitionRequest
from .recognition_response import RecognitionResponse
from .recognized_polygon_model import RecognizedPolygonModel
from .refresh_request import RefreshRequest
from .refresh_response import RefreshResponse
from .string_segment import StringSegment
from .test_request import TestRequest
from .update_legend_body import UpdateLegendBody
from .wgs_84_coord_dto import Wgs84CoordDto
from .wgs_84_rectangle_dto import Wgs84RectangleDto

__all__ = (
    "AuthErrorCode",
    "AuthErrorResponse",
    "AutoCreateLegendWithImageBody",
    "DirectoryContentsDto",
    "EnsureDirectoriesRequest",
    "EnsureDirectoriesResponse",
    "EntityTagHeaderValue",
    "ExampleRequest",
    "FileStreamHttpResult",
    "GeoJsonPolygon",
    "HttpValidationProblemDetails",
    "HttpValidationProblemDetailsErrorsType0",
    "LegendAutoCreateRequest",
    "LegendItemModel",
    "LegendModel",
    "ListDirectoryContentsRequest",
    "ListDirectoryContentsResponse",
    "LoginRequest",
    "LoginResponse",
    "LogoutRequest",
    "ProcessRecognitionWithImageBody",
    "QgisExtentDto",
    "RecognitionRequest",
    "RecognitionResponse",
    "RecognizedPolygonModel",
    "RefreshRequest",
    "RefreshResponse",
    "StringSegment",
    "TestRequest",
    "UpdateLegendBody",
    "Wgs84CoordDto",
    "Wgs84RectangleDto",
)
