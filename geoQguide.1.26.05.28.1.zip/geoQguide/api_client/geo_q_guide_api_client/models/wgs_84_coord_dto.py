from collections.abc import Mapping
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="Wgs84CoordDto")


@_attrs_define
class Wgs84CoordDto:
    """
    Attributes:
        lat (Union[Unset, float]):
        lon (Union[Unset, float]):
    """

    lat: Union[Unset, float] = UNSET
    lon: Union[Unset, float] = UNSET

    def to_dict(self) -> dict[str, Any]:
        lat = self.lat

        lon = self.lon

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if lat is not UNSET:
            field_dict["lat"] = lat
        if lon is not UNSET:
            field_dict["lon"] = lon

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        lat = d.pop("lat", UNSET)

        lon = d.pop("lon", UNSET)

        wgs_84_coord_dto = cls(
            lat=lat,
            lon=lon,
        )

        return wgs_84_coord_dto
