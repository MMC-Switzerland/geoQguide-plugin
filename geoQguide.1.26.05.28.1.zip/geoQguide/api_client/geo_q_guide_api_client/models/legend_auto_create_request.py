from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.qgis_extent_dto import QgisExtentDto


T = TypeVar("T", bound="LegendAutoCreateRequest")


@_attrs_define
class LegendAutoCreateRequest:
    """
    Attributes:
        data_source_uri (Union[None, Unset, str]):
        sensitivity (Union[Unset, int]):
        tile_size (Union[Unset, int]):
        extent (Union[Unset, QgisExtentDto]):
    """

    data_source_uri: Union[None, Unset, str] = UNSET
    sensitivity: Union[Unset, int] = UNSET
    tile_size: Union[Unset, int] = UNSET
    extent: Union[Unset, "QgisExtentDto"] = UNSET

    def to_dict(self) -> dict[str, Any]:
        data_source_uri: Union[None, Unset, str]
        if isinstance(self.data_source_uri, Unset):
            data_source_uri = UNSET
        else:
            data_source_uri = self.data_source_uri

        sensitivity = self.sensitivity

        tile_size = self.tile_size

        extent: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.extent, Unset):
            extent = self.extent.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if data_source_uri is not UNSET:
            field_dict["dataSourceUri"] = data_source_uri
        if sensitivity is not UNSET:
            field_dict["sensitivity"] = sensitivity
        if tile_size is not UNSET:
            field_dict["tileSize"] = tile_size
        if extent is not UNSET:
            field_dict["extent"] = extent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.qgis_extent_dto import QgisExtentDto

        d = dict(src_dict)

        def _parse_data_source_uri(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        data_source_uri = _parse_data_source_uri(d.pop("dataSourceUri", UNSET))

        sensitivity = d.pop("sensitivity", UNSET)

        tile_size = d.pop("tileSize", UNSET)

        _extent = d.pop("extent", UNSET)
        extent: Union[Unset, QgisExtentDto]
        if isinstance(_extent, Unset):
            extent = UNSET
        else:
            extent = QgisExtentDto.from_dict(_extent)

        legend_auto_create_request = cls(
            data_source_uri=data_source_uri,
            sensitivity=sensitivity,
            tile_size=tile_size,
            extent=extent,
        )

        return legend_auto_create_request
