from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="RefreshRequest")


@_attrs_define
class RefreshRequest:
    """
    Attributes:
        refresh_token (Union[None, Unset, str]):
        device_fingerprint (Union[None, Unset, str]):
    """

    refresh_token: Union[None, Unset, str] = UNSET
    device_fingerprint: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        refresh_token: Union[None, Unset, str]
        if isinstance(self.refresh_token, Unset):
            refresh_token = UNSET
        else:
            refresh_token = self.refresh_token

        device_fingerprint: Union[None, Unset, str]
        if isinstance(self.device_fingerprint, Unset):
            device_fingerprint = UNSET
        else:
            device_fingerprint = self.device_fingerprint

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if refresh_token is not UNSET:
            field_dict["refreshToken"] = refresh_token
        if device_fingerprint is not UNSET:
            field_dict["deviceFingerprint"] = device_fingerprint

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_refresh_token(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        refresh_token = _parse_refresh_token(d.pop("refreshToken", UNSET))

        def _parse_device_fingerprint(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        device_fingerprint = _parse_device_fingerprint(d.pop("deviceFingerprint", UNSET))

        refresh_request = cls(
            refresh_token=refresh_token,
            device_fingerprint=device_fingerprint,
        )

        return refresh_request
