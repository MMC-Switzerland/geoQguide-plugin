from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="LogoutRequest")


@_attrs_define
class LogoutRequest:
    """
    Attributes:
        refresh_token (Union[None, Unset, str]):
    """

    refresh_token: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        refresh_token: Union[None, Unset, str]
        if isinstance(self.refresh_token, Unset):
            refresh_token = UNSET
        else:
            refresh_token = self.refresh_token

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if refresh_token is not UNSET:
            field_dict["refreshToken"] = refresh_token

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_refresh_token(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        refresh_token = _parse_refresh_token(d.pop("refreshToken", UNSET))

        logout_request = cls(
            refresh_token=refresh_token,
        )

        return logout_request
