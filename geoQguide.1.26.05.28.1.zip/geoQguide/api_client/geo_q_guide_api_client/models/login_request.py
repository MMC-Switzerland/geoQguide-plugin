from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="LoginRequest")


@_attrs_define
class LoginRequest:
    """
    Attributes:
        email (Union[None, Unset, str]):
        password (Union[None, Unset, str]):
        device_fingerprint (Union[None, Unset, str]):
        machine_name (Union[None, Unset, str]):
        confirm_device_switch (Union[Unset, bool]):
    """

    email: Union[None, Unset, str] = UNSET
    password: Union[None, Unset, str] = UNSET
    device_fingerprint: Union[None, Unset, str] = UNSET
    machine_name: Union[None, Unset, str] = UNSET
    confirm_device_switch: Union[Unset, bool] = UNSET

    def to_dict(self) -> dict[str, Any]:
        email: Union[None, Unset, str]
        if isinstance(self.email, Unset):
            email = UNSET
        else:
            email = self.email

        password: Union[None, Unset, str]
        if isinstance(self.password, Unset):
            password = UNSET
        else:
            password = self.password

        device_fingerprint: Union[None, Unset, str]
        if isinstance(self.device_fingerprint, Unset):
            device_fingerprint = UNSET
        else:
            device_fingerprint = self.device_fingerprint

        machine_name: Union[None, Unset, str]
        if isinstance(self.machine_name, Unset):
            machine_name = UNSET
        else:
            machine_name = self.machine_name

        confirm_device_switch = self.confirm_device_switch

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if email is not UNSET:
            field_dict["email"] = email
        if password is not UNSET:
            field_dict["password"] = password
        if device_fingerprint is not UNSET:
            field_dict["deviceFingerprint"] = device_fingerprint
        if machine_name is not UNSET:
            field_dict["machineName"] = machine_name
        if confirm_device_switch is not UNSET:
            field_dict["confirmDeviceSwitch"] = confirm_device_switch

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_email(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        email = _parse_email(d.pop("email", UNSET))

        def _parse_password(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        password = _parse_password(d.pop("password", UNSET))

        def _parse_device_fingerprint(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        device_fingerprint = _parse_device_fingerprint(d.pop("deviceFingerprint", UNSET))

        def _parse_machine_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        machine_name = _parse_machine_name(d.pop("machineName", UNSET))

        confirm_device_switch = d.pop("confirmDeviceSwitch", UNSET)

        login_request = cls(
            email=email,
            password=password,
            device_fingerprint=device_fingerprint,
            machine_name=machine_name,
            confirm_device_switch=confirm_device_switch,
        )

        return login_request
