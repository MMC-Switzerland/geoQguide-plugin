from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, File, FileTypes, Unset

T = TypeVar("T", bound="UpdateLegendBody")


@_attrs_define
class UpdateLegendBody:
    """
    Attributes:
        data_source_uri (str): The QGIS data source URI of the layer Example: contextualWMSLegend=0&crs=EPSG:32632&dpiMo
            de=7&featureCount=10&format=image/png&layers=ulter_cont_unesco&styles&tilePixelRatio=0&url=http://www502.regione
            .toscana.it/wmsraster/com.rt.wms.RTmap/wms?map%3Dwmspiapae%26map_resolution%3D91.
        items0_name (str): Name of the first legend item Example: Forest.
        items0_image (File): Image file for the first legend item
        items_0_is_background (Union[Unset, bool]): Whether the first legend item is a background item (optional,
            defaults to false)
        items1_name (Union[Unset, str]): Name of the second legend item Example: Water.
        items1_image (Union[Unset, File]): Image file for the second legend item
        items_1_is_background (Union[Unset, bool]): Whether the second legend item is a background item (optional,
            defaults to false) Example: True.
    """

    data_source_uri: str
    items0_name: str
    items0_image: File
    items_0_is_background: Union[Unset, bool] = UNSET
    items1_name: Union[Unset, str] = UNSET
    items1_image: Union[Unset, File] = UNSET
    items_1_is_background: Union[Unset, bool] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data_source_uri = self.data_source_uri

        items0_name = self.items0_name

        items0_image = self.items0_image.to_tuple()

        items_0_is_background = self.items_0_is_background

        items1_name = self.items1_name

        items1_image: Union[Unset, FileTypes] = UNSET
        if not isinstance(self.items1_image, Unset):
            items1_image = self.items1_image.to_tuple()

        items_1_is_background = self.items_1_is_background

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dataSourceUri": data_source_uri,
                "items[0].name": items0_name,
                "items[0].image": items0_image,
            }
        )
        if items_0_is_background is not UNSET:
            field_dict["items[0].isBackground"] = items_0_is_background
        if items1_name is not UNSET:
            field_dict["items[1].name"] = items1_name
        if items1_image is not UNSET:
            field_dict["items[1].image"] = items1_image
        if items_1_is_background is not UNSET:
            field_dict["items[1].isBackground"] = items_1_is_background

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("dataSourceUri", (None, str(self.data_source_uri).encode(), "text/plain")))

        files.append(("items[0].name", (None, str(self.items0_name).encode(), "text/plain")))

        files.append(("items[0].image", self.items0_image.to_tuple()))

        if not isinstance(self.items_0_is_background, Unset):
            files.append(("items[0].isBackground", (None, str(self.items_0_is_background).encode(), "text/plain")))

        if not isinstance(self.items1_name, Unset):
            files.append(("items[1].name", (None, str(self.items1_name).encode(), "text/plain")))

        if not isinstance(self.items1_image, Unset):
            files.append(("items[1].image", self.items1_image.to_tuple()))

        if not isinstance(self.items_1_is_background, Unset):
            files.append(("items[1].isBackground", (None, str(self.items_1_is_background).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        data_source_uri = d.pop("dataSourceUri")

        items0_name = d.pop("items[0].name")

        items0_image = File(payload=BytesIO(d.pop("items[0].image")))

        items_0_is_background = d.pop("items[0].isBackground", UNSET)

        items1_name = d.pop("items[1].name", UNSET)

        _items1_image = d.pop("items[1].image", UNSET)
        items1_image: Union[Unset, File]
        if isinstance(_items1_image, Unset):
            items1_image = UNSET
        else:
            items1_image = File(payload=BytesIO(_items1_image))

        items_1_is_background = d.pop("items[1].isBackground", UNSET)

        update_legend_body = cls(
            data_source_uri=data_source_uri,
            items0_name=items0_name,
            items0_image=items0_image,
            items_0_is_background=items_0_is_background,
            items1_name=items1_name,
            items1_image=items1_image,
            items_1_is_background=items_1_is_background,
        )

        update_legend_body.additional_properties = d
        return update_legend_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
