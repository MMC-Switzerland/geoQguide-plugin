from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.legend_item_model import LegendItemModel


T = TypeVar("T", bound="LegendModel")


@_attrs_define
class LegendModel:
    """
    Attributes:
        items (Union[None, list['LegendItemModel']]):
        id (Union[Unset, int]):
    """

    items: Union[None, list["LegendItemModel"]]
    id: Union[Unset, int] = UNSET

    def to_dict(self) -> dict[str, Any]:
        items: Union[None, list[dict[str, Any]]]
        if isinstance(self.items, list):
            items = []
            for items_type_0_item_data in self.items:
                items_type_0_item = items_type_0_item_data.to_dict()
                items.append(items_type_0_item)

        else:
            items = self.items

        id = self.id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "items": items,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.legend_item_model import LegendItemModel

        d = dict(src_dict)

        def _parse_items(data: object) -> Union[None, list["LegendItemModel"]]:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                items_type_0 = []
                _items_type_0 = data
                for items_type_0_item_data in _items_type_0:
                    items_type_0_item = LegendItemModel.from_dict(items_type_0_item_data)

                    items_type_0.append(items_type_0_item)

                return items_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, list["LegendItemModel"]], data)

        items = _parse_items(d.pop("items"))

        id = d.pop("id", UNSET)

        legend_model = cls(
            items=items,
            id=id,
        )

        return legend_model
