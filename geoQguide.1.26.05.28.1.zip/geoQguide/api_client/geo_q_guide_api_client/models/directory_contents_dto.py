from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="DirectoryContentsDto")


@_attrs_define
class DirectoryContentsDto:
    """
    Attributes:
        directory_path (Union[None, str]):
        files (Union[None, list[str]]):
        folders (Union[None, list[str]]):
        exists (Union[Unset, bool]):
        total_files (Union[Unset, int]):
        total_folders (Union[Unset, int]):
    """

    directory_path: Union[None, str]
    files: Union[None, list[str]]
    folders: Union[None, list[str]]
    exists: Union[Unset, bool] = UNSET
    total_files: Union[Unset, int] = UNSET
    total_folders: Union[Unset, int] = UNSET

    def to_dict(self) -> dict[str, Any]:
        directory_path: Union[None, str]
        directory_path = self.directory_path

        files: Union[None, list[str]]
        if isinstance(self.files, list):
            files = self.files

        else:
            files = self.files

        folders: Union[None, list[str]]
        if isinstance(self.folders, list):
            folders = self.folders

        else:
            folders = self.folders

        exists = self.exists

        total_files = self.total_files

        total_folders = self.total_folders

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "directoryPath": directory_path,
                "files": files,
                "folders": folders,
            }
        )
        if exists is not UNSET:
            field_dict["exists"] = exists
        if total_files is not UNSET:
            field_dict["totalFiles"] = total_files
        if total_folders is not UNSET:
            field_dict["totalFolders"] = total_folders

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_directory_path(data: object) -> Union[None, str]:
            if data is None:
                return data
            return cast(Union[None, str], data)

        directory_path = _parse_directory_path(d.pop("directoryPath"))

        def _parse_files(data: object) -> Union[None, list[str]]:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                files_type_0 = cast(list[str], data)

                return files_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, list[str]], data)

        files = _parse_files(d.pop("files"))

        def _parse_folders(data: object) -> Union[None, list[str]]:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                folders_type_0 = cast(list[str], data)

                return folders_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, list[str]], data)

        folders = _parse_folders(d.pop("folders"))

        exists = d.pop("exists", UNSET)

        total_files = d.pop("totalFiles", UNSET)

        total_folders = d.pop("totalFolders", UNSET)

        directory_contents_dto = cls(
            directory_path=directory_path,
            files=files,
            folders=folders,
            exists=exists,
            total_files=total_files,
            total_folders=total_folders,
        )

        return directory_contents_dto
