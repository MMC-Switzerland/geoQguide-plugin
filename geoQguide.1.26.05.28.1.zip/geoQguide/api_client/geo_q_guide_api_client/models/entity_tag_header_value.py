from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.string_segment import StringSegment


T = TypeVar("T", bound="EntityTagHeaderValue")


@_attrs_define
class EntityTagHeaderValue:
    """
    Attributes:
        tag (Union[Unset, StringSegment]):
        is_weak (Union[Unset, bool]):
    """

    tag: Union[Unset, "StringSegment"] = UNSET
    is_weak: Union[Unset, bool] = UNSET

    def to_dict(self) -> dict[str, Any]:
        tag: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.tag, Unset):
            tag = self.tag.to_dict()

        is_weak = self.is_weak

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if tag is not UNSET:
            field_dict["tag"] = tag
        if is_weak is not UNSET:
            field_dict["isWeak"] = is_weak

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.string_segment import StringSegment

        d = dict(src_dict)
        _tag = d.pop("tag", UNSET)
        tag: Union[Unset, StringSegment]
        if isinstance(_tag, Unset):
            tag = UNSET
        else:
            tag = StringSegment.from_dict(_tag)

        is_weak = d.pop("isWeak", UNSET)

        entity_tag_header_value = cls(
            tag=tag,
            is_weak=is_weak,
        )

        return entity_tag_header_value
