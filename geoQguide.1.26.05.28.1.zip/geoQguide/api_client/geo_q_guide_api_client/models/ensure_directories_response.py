from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

T = TypeVar("T", bound="EnsureDirectoriesResponse")


@_attrs_define
class EnsureDirectoriesResponse:
    """
    Attributes:
        message (Union[None, str]):
        created_directories (Union[None, list[str]]):
    """

    message: Union[None, str]
    created_directories: Union[None, list[str]]

    def to_dict(self) -> dict[str, Any]:
        message: Union[None, str]
        message = self.message

        created_directories: Union[None, list[str]]
        if isinstance(self.created_directories, list):
            created_directories = self.created_directories

        else:
            created_directories = self.created_directories

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "message": message,
                "createdDirectories": created_directories,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_message(data: object) -> Union[None, str]:
            if data is None:
                return data
            return cast(Union[None, str], data)

        message = _parse_message(d.pop("message"))

        def _parse_created_directories(data: object) -> Union[None, list[str]]:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                created_directories_type_0 = cast(list[str], data)

                return created_directories_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, list[str]], data)

        created_directories = _parse_created_directories(d.pop("createdDirectories"))

        ensure_directories_response = cls(
            message=message,
            created_directories=created_directories,
        )

        return ensure_directories_response
