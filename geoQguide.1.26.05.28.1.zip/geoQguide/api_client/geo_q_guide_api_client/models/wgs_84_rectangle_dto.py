from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.wgs_84_coord_dto import Wgs84CoordDto


T = TypeVar("T", bound="Wgs84RectangleDto")


@_attrs_define
class Wgs84RectangleDto:
    """
    Attributes:
        min_ (Union[Unset, Wgs84CoordDto]):
        max_ (Union[Unset, Wgs84CoordDto]):
    """

    min_: Union[Unset, "Wgs84CoordDto"] = UNSET
    max_: Union[Unset, "Wgs84CoordDto"] = UNSET

    def to_dict(self) -> dict[str, Any]:
        min_: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.min_, Unset):
            min_ = self.min_.to_dict()

        max_: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.max_, Unset):
            max_ = self.max_.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if min_ is not UNSET:
            field_dict["min"] = min_
        if max_ is not UNSET:
            field_dict["max"] = max_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.wgs_84_coord_dto import Wgs84CoordDto

        d = dict(src_dict)
        _min_ = d.pop("min", UNSET)
        min_: Union[Unset, Wgs84CoordDto]
        if isinstance(_min_, Unset):
            min_ = UNSET
        else:
            min_ = Wgs84CoordDto.from_dict(_min_)

        _max_ = d.pop("max", UNSET)
        max_: Union[Unset, Wgs84CoordDto]
        if isinstance(_max_, Unset):
            max_ = UNSET
        else:
            max_ = Wgs84CoordDto.from_dict(_max_)

        wgs_84_rectangle_dto = cls(
            min_=min_,
            max_=max_,
        )

        return wgs_84_rectangle_dto
