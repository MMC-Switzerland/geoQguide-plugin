from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="LegendItemModel")


@_attrs_define
class LegendItemModel:
    """
    Attributes:
        id (Union[Unset, int]):
        name (Union[None, Unset, str]):
        image_url (Union[None, Unset, str]):
        is_background (Union[Unset, bool]):
    """

    id: Union[Unset, int] = UNSET
    name: Union[None, Unset, str] = UNSET
    image_url: Union[None, Unset, str] = UNSET
    is_background: Union[Unset, bool] = UNSET

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name: Union[None, Unset, str]
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        image_url: Union[None, Unset, str]
        if isinstance(self.image_url, Unset):
            image_url = UNSET
        else:
            image_url = self.image_url

        is_background = self.is_background

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if name is not UNSET:
            field_dict["name"] = name
        if image_url is not UNSET:
            field_dict["imageUrl"] = image_url
        if is_background is not UNSET:
            field_dict["isBackground"] = is_background

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        def _parse_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_image_url(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        image_url = _parse_image_url(d.pop("imageUrl", UNSET))

        is_background = d.pop("isBackground", UNSET)

        legend_item_model = cls(
            id=id,
            name=name,
            image_url=image_url,
            is_background=is_background,
        )

        return legend_item_model
