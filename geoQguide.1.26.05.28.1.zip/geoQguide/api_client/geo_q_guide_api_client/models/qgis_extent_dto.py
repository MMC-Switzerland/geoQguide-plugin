from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.wgs_84_rectangle_dto import Wgs84RectangleDto


T = TypeVar("T", bound="QgisExtentDto")


@_attrs_define
class QgisExtentDto:
    """
    Attributes:
        extent (Union[Unset, Wgs84RectangleDto]):
        zoom_level (Union[Unset, int]):
    """

    extent: Union[Unset, "Wgs84RectangleDto"] = UNSET
    zoom_level: Union[Unset, int] = UNSET

    def to_dict(self) -> dict[str, Any]:
        extent: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.extent, Unset):
            extent = self.extent.to_dict()

        zoom_level = self.zoom_level

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if extent is not UNSET:
            field_dict["extent"] = extent
        if zoom_level is not UNSET:
            field_dict["zoomLevel"] = zoom_level

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.wgs_84_rectangle_dto import Wgs84RectangleDto

        d = dict(src_dict)
        _extent = d.pop("extent", UNSET)
        extent: Union[Unset, Wgs84RectangleDto]
        if isinstance(_extent, Unset):
            extent = UNSET
        else:
            extent = Wgs84RectangleDto.from_dict(_extent)

        zoom_level = d.pop("zoomLevel", UNSET)

        qgis_extent_dto = cls(
            extent=extent,
            zoom_level=zoom_level,
        )

        return qgis_extent_dto
