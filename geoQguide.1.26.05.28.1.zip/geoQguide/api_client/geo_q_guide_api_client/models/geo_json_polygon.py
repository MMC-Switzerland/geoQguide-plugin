from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="GeoJsonPolygon")


@_attrs_define
class GeoJsonPolygon:
    """
    Attributes:
        type_ (Union[None, Unset, str]):
        coordinates (Union[None, Unset, list[list[list[float]]]]):
    """

    type_: Union[None, Unset, str] = UNSET
    coordinates: Union[None, Unset, list[list[list[float]]]] = UNSET

    def to_dict(self) -> dict[str, Any]:
        type_: Union[None, Unset, str]
        if isinstance(self.type_, Unset):
            type_ = UNSET
        else:
            type_ = self.type_

        coordinates: Union[None, Unset, list[list[list[float]]]]
        if isinstance(self.coordinates, Unset):
            coordinates = UNSET
        elif isinstance(self.coordinates, list):
            coordinates = []
            for coordinates_type_0_item_data in self.coordinates:
                coordinates_type_0_item = []
                for coordinates_type_0_item_item_data in coordinates_type_0_item_data:
                    coordinates_type_0_item_item = coordinates_type_0_item_item_data

                    coordinates_type_0_item.append(coordinates_type_0_item_item)

                coordinates.append(coordinates_type_0_item)

        else:
            coordinates = self.coordinates

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if type_ is not UNSET:
            field_dict["type"] = type_
        if coordinates is not UNSET:
            field_dict["coordinates"] = coordinates

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_type_(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        type_ = _parse_type_(d.pop("type", UNSET))

        def _parse_coordinates(data: object) -> Union[None, Unset, list[list[list[float]]]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                coordinates_type_0 = []
                _coordinates_type_0 = data
                for coordinates_type_0_item_data in _coordinates_type_0:
                    coordinates_type_0_item = []
                    _coordinates_type_0_item = coordinates_type_0_item_data
                    for coordinates_type_0_item_item_data in _coordinates_type_0_item:
                        coordinates_type_0_item_item = cast(list[float], coordinates_type_0_item_item_data)

                        coordinates_type_0_item.append(coordinates_type_0_item_item)

                    coordinates_type_0.append(coordinates_type_0_item)

                return coordinates_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list[list[list[float]]]], data)

        coordinates = _parse_coordinates(d.pop("coordinates", UNSET))

        geo_json_polygon = cls(
            type_=type_,
            coordinates=coordinates,
        )

        return geo_json_polygon
