from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.geo_json_polygon import GeoJsonPolygon


T = TypeVar("T", bound="RecognitionRequest")


@_attrs_define
class RecognitionRequest:
    """
    Attributes:
        polygon (Union[Unset, GeoJsonPolygon]):
        data_source_uri (Union[None, Unset, str]):
    """

    polygon: Union[Unset, "GeoJsonPolygon"] = UNSET
    data_source_uri: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        polygon: Union[Unset, dict[str, Any]] = UNSET
        if not isinstance(self.polygon, Unset):
            polygon = self.polygon.to_dict()

        data_source_uri: Union[None, Unset, str]
        if isinstance(self.data_source_uri, Unset):
            data_source_uri = UNSET
        else:
            data_source_uri = self.data_source_uri

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if polygon is not UNSET:
            field_dict["polygon"] = polygon
        if data_source_uri is not UNSET:
            field_dict["dataSourceUri"] = data_source_uri

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.geo_json_polygon import GeoJsonPolygon

        d = dict(src_dict)
        _polygon = d.pop("polygon", UNSET)
        polygon: Union[Unset, GeoJsonPolygon]
        if isinstance(_polygon, Unset):
            polygon = UNSET
        else:
            polygon = GeoJsonPolygon.from_dict(_polygon)

        def _parse_data_source_uri(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        data_source_uri = _parse_data_source_uri(d.pop("dataSourceUri", UNSET))

        recognition_request = cls(
            polygon=polygon,
            data_source_uri=data_source_uri,
        )

        return recognition_request
