from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.recognized_polygon_model import RecognizedPolygonModel


T = TypeVar("T", bound="RecognitionResponse")


@_attrs_define
class RecognitionResponse:
    """
    Attributes:
        recognized_polygons (Union[None, Unset, list['RecognizedPolygonModel']]):
    """

    recognized_polygons: Union[None, Unset, list["RecognizedPolygonModel"]] = UNSET

    def to_dict(self) -> dict[str, Any]:
        recognized_polygons: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.recognized_polygons, Unset):
            recognized_polygons = UNSET
        elif isinstance(self.recognized_polygons, list):
            recognized_polygons = []
            for recognized_polygons_type_0_item_data in self.recognized_polygons:
                recognized_polygons_type_0_item = recognized_polygons_type_0_item_data.to_dict()
                recognized_polygons.append(recognized_polygons_type_0_item)

        else:
            recognized_polygons = self.recognized_polygons

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if recognized_polygons is not UNSET:
            field_dict["recognizedPolygons"] = recognized_polygons

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.recognized_polygon_model import RecognizedPolygonModel

        d = dict(src_dict)

        def _parse_recognized_polygons(data: object) -> Union[None, Unset, list["RecognizedPolygonModel"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                recognized_polygons_type_0 = []
                _recognized_polygons_type_0 = data
                for recognized_polygons_type_0_item_data in _recognized_polygons_type_0:
                    recognized_polygons_type_0_item = RecognizedPolygonModel.from_dict(
                        recognized_polygons_type_0_item_data
                    )

                    recognized_polygons_type_0.append(recognized_polygons_type_0_item)

                return recognized_polygons_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["RecognizedPolygonModel"]], data)

        recognized_polygons = _parse_recognized_polygons(d.pop("recognizedPolygons", UNSET))

        recognition_response = cls(
            recognized_polygons=recognized_polygons,
        )

        return recognition_response
