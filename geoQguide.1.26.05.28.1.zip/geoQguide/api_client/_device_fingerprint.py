import hashlib
import platform
import uuid


def get_hostname() -> str:
    return platform.node()


def get_device_fingerprint() -> str:
    """Stable hardware/OS fingerprint for this machine.

    Components:
      - hostname       : identifies the machine (intentional to change)
      - CPU arch       : e.g. AMD64 — stable unless CPU replaced
      - processor name : CPU brand string — stable unless CPU replaced
      - MAC address    : primary NIC MAC — stable on physical machines

    Deliberately excluded:
      - OS version     : changes on routine updates
      - Python version : changes on updates
    """
    parts = [
        platform.node(),        # hostname
        platform.machine(),     # CPU arch, e.g. AMD64
        platform.processor(),   # CPU brand string
        str(uuid.getnode()),    # MAC address of primary NIC
    ]
    raw = "|".join(parts).encode()
    return hashlib.sha256(raw).hexdigest()
