class AuthError(Exception):
    """Raised when login or token operation fails."""


class DeviceSwitchRequired(AuthError):
    """Login from a new device fingerprint — re-submit with confirm_device_switch=True."""


class DeviceSwitchCooldown(AuthError):
    """Device switch not allowed yet — 30-day cooldown has not elapsed."""


class SessionExpiredError(AuthError):
    """Raised when the refresh token is invalid or expired. User must log in again."""
