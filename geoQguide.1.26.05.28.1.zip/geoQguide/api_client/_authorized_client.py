from __future__ import annotations

from typing import TYPE_CHECKING

from .geo_q_guide_api_client.client import AuthenticatedClient

if TYPE_CHECKING:
    from ._auth_session import AuthSession
    from ._token_store import TokenStore


class AuthorizedClient:
    """Returns an AuthenticatedClient with a fresh Bearer token, refreshing proactively."""

    def __init__(self, base_url: str, store: TokenStore, session: AuthSession, verify_ssl: bool = True) -> None:
        self._base_url = base_url
        self._store = store
        self._session = session
        self._verify_ssl = verify_ssl

    def get(self) -> AuthenticatedClient:
        """Return an AuthenticatedClient with a valid access token.

        Proactively refreshes the token if it expires within 60 seconds.
        Raises SessionExpiredError if the refresh token is also invalid.
        """
        if not self._store.is_access_token_fresh():
            self._session.refresh()
        return AuthenticatedClient(
            base_url=self._base_url,
            token=self._store.access_token,
            verify_ssl=self._verify_ssl,
        )
