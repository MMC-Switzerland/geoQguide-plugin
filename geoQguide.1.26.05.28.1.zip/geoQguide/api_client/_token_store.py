import base64
import json
import time

_ACCESS_KEY = "geoqguide_access_token"
_REFRESH_KEY = "geoqguide_refresh_token"


def _auth_manager():
    from qgis.core import QgsApplication  # noqa: PLC0415 — lazy import, not available outside QGIS
    return QgsApplication.authManager()


def _jwt_exp(token: str) -> float:
    """Decode the `exp` claim from a JWT without verifying the signature."""
    payload = token.split(".")[1]
    payload += "=" * (-len(payload) % 4)  # restore base64 padding
    return json.loads(base64.urlsafe_b64decode(payload))["exp"]


class TokenStore:
    """Persists access and refresh tokens in QgsAuthManager (encrypted)."""

    @property
    def access_token(self) -> str | None:
        val = _auth_manager().authSetting(_ACCESS_KEY, "", True)
        return val or None

    @property
    def refresh_token(self) -> str | None:
        val = _auth_manager().authSetting(_REFRESH_KEY, "", True)
        return val or None

    def set_tokens(self, access_token: str, refresh_token: str) -> None:
        mgr = _auth_manager()
        mgr.storeAuthSetting(_ACCESS_KEY, access_token, True)
        mgr.storeAuthSetting(_REFRESH_KEY, refresh_token, True)

    def clear(self) -> None:
        mgr = _auth_manager()
        mgr.removeAuthSetting(_ACCESS_KEY)
        mgr.removeAuthSetting(_REFRESH_KEY)

    def is_access_token_fresh(self, buffer_seconds: int = 60) -> bool:
        """Return True if the access token exists and does not expire within buffer_seconds."""
        token = self.access_token
        if not token:
            return False
        try:
            return _jwt_exp(token) - time.time() > buffer_seconds
        except Exception:
            return False
