import base64
import json
import time


def _jwt_exp(token: str) -> float:
    payload = token.split(".")[1]
    payload += "=" * (-len(payload) % 4)
    return json.loads(base64.urlsafe_b64decode(payload))["exp"]


class MemoryTokenStore:
    """In-memory token store — for testing outside of QGIS."""

    def __init__(self) -> None:
        self._access_token: str | None = None
        self._refresh_token: str | None = None

    @property
    def access_token(self) -> str | None:
        return self._access_token

    @property
    def refresh_token(self) -> str | None:
        return self._refresh_token

    def set_tokens(self, access_token: str, refresh_token: str) -> None:
        self._access_token = access_token
        self._refresh_token = refresh_token

    def clear(self) -> None:
        self._access_token = None
        self._refresh_token = None

    def is_access_token_fresh(self, buffer_seconds: int = 60) -> bool:
        token = self._access_token
        if not token:
            return False
        try:
            return _jwt_exp(token) - time.time() > buffer_seconds
        except Exception:
            return False
