from typing import Callable, TypeVar

from ._auth_session import AuthSession
from ._authorized_client import AuthorizedClient
from ._device_fingerprint import get_device_fingerprint
from .geo_q_guide_api_client.client import AuthenticatedClient
from .geo_q_guide_api_client.types import Response

_T = TypeVar("_T")


def _make_store():
    """Return TokenStore when running inside QGIS, MemoryTokenStore otherwise."""
    try:
        import qgis.core  # noqa: F401
        from ._token_store import TokenStore
        return TokenStore()
    except ModuleNotFoundError:
        from ._memory_token_store import MemoryTokenStore
        return MemoryTokenStore()


class GeoQGuideApiClient:
    """High-level client for the GeoQGuide API with automatic JWT auth."""

    def __init__(
        self,
        base_url: str,
        verify_ssl: bool = True,
    ) -> None:
        self._base_url = base_url
        from urllib.parse import urlparse
        parsed = urlparse(base_url)
        if parsed.hostname in ("localhost", "127.0.0.1", "::1"):
            verify_ssl = False
        self._store = _make_store()
        _fingerprint = get_device_fingerprint()
        self._session = AuthSession(base_url, _fingerprint, self._store, verify_ssl=verify_ssl)
        self._authorized = AuthorizedClient(base_url, self._store, self._session, verify_ssl=verify_ssl)

    def login(self, email: str, password: str, confirm_device_switch: bool = False) -> None:
        """Authenticate and store tokens. Raises AuthError subclasses on failure."""
        self._session.login(email, password, confirm_device_switch)

    def logout(self) -> None:
        """Revoke the refresh token server-side and clear stored tokens."""
        self._session.logout()

    def call(self, fn: Callable[..., Response[_T]], **kwargs) -> Response[_T]:
        """Call a generated API function with automatic token management.

        Proactively refreshes the token before the call if it is near expiry.
        On a 401 response (token invalidated server-side), refreshes once and retries.

        Usage::

            from api_client.geo_q_guide_api_client.api.recognition import recognize
            resp = gq.call(recognize.sync_detailed, body=RecognitionRequest(...))
        """
        resp = fn(client=self._authorized.get(), **kwargs)
        if resp.status_code == 401:
            self._session.refresh()
            resp = fn(client=self._authorized.get(), **kwargs)
        return resp

    @property
    def is_authenticated(self) -> bool:
        """Return True if the client has stored tokens (user is logged in)."""
        return bool(self._store.access_token)

    def get_authorized_client(self) -> AuthenticatedClient:
        """Return a raw AuthenticatedClient for direct use with generated API functions."""
        return self._authorized.get()
