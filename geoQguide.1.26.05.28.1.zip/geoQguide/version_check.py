from __future__ import annotations
import re
from datetime import date
from qgis.PyQt.QtCore import QThread,pyqtSignal
from qgis.core import Qgis,QgsSettings
PLUGINS_XML_URL='https://raw.githubusercontent.com/MMC-Switzerland/geoQguide-plugin/refs/heads/master/plugins.xml'
PLUGIN_KEY='plugins/geoQguide'
CHECK_DATE_KEY=f"{PLUGIN_KEY}/last_version_check"
def _parse_version(xml):A=re.search('<version>\\s*([^<\\s]+)\\s*</version>',xml);return A.group(1)if A else None
def _version_tuple(v):
	try:return tuple(int(A)for A in v.split('.'))
	except ValueError:return 0,
class _VersionCheckThread(QThread):
	update_available=pyqtSignal(str)
	def __init__(A,current_version):super().__init__();A._current=current_version
	def run(B):
		try:
			from urllib.request import urlopen as C
			with C(PLUGINS_XML_URL,timeout=10)as D:E=D.read().decode('utf-8',errors='replace')
			A=_parse_version(E)
			if A and _version_tuple(A)>_version_tuple(B._current):B.update_available.emit(A)
		except Exception:pass
def schedule_check(current_version,iface):
	B=iface;C=str(date.today());D=QgsSettings()
	if D.value(CHECK_DATE_KEY,'')==C:return
	D.setValue(CHECK_DATE_KEY,C);A=_VersionCheckThread(current_version);A.update_available.connect(lambda v:_show_bar(v,B));B._geoqguide_version_thread=A;A.start()
def _show_bar(latest,iface):iface.messageBar().pushMessage('geoQguide',f"Version {latest} is available — go to Plugins → Manage → Upgradable to install.",level=Qgis.Info,duration=0)