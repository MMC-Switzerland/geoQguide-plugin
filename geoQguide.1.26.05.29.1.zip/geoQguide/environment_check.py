from __future__ import annotations
import os,platform,importlib.util,inspect
from typing import List,Dict,Optional
from qgis.PyQt.QtWidgets import QDialog,QVBoxLayout,QLabel,QScrollArea,QWidget,QTextBrowser
from qgis.PyQt.QtCore import Qt
from qgis.core import QgsMessageLog,Qgis
try:from qgis.utils import iface
except Exception:iface=globals().get('iface',None)
GQG_AUTO_RUN=globals().get('GQG_AUTO_RUN',True)
GQG_LOCAL_DIR=globals().get('GQG_LOCAL_DIR',None)
def log(msg,level=Qgis.Info):
	try:print(f"[Environment] {msg}")
	except Exception:pass
	try:QgsMessageLog.logMessage(str(msg),'GeoQGuide',level)
	except Exception:pass
	if iface:
		try:iface.messageBar().pushMessage('GeoQGuide',str(msg),level=0,duration=4)
		except Exception:pass
def _resolve_local_dir(local=None):
	if local and os.path.isdir(local):return local
	if GQG_LOCAL_DIR and os.path.isdir(GQG_LOCAL_DIR):return GQG_LOCAL_DIR
	try:
		here=os.path.dirname(inspect.stack()[0].filename)
		if here and os.path.isdir(here):return here
	except Exception:pass
	return os.getcwd()
REQUIRED_LIBRARIES=['numpy','PIL','skimage','requests','duckdb','docx','httpx','attrs','matplotlib','cryptography','dateutil']
PIP_NAME_MAP={'PIL':'pillow','skimage':'scikit-image','docx':'python-docx','dateutil':'python-dateutil'}
OS_NAME=platform.system()
def is_library_available(pkg_name):
	try:return importlib.util.find_spec(pkg_name)is not None
	except Exception:return False
def scan_required_libraries():
	results={}
	for lib in REQUIRED_LIBRARIES:results[lib]=is_library_available(lib)
	return results
def find_osgeo4w_root():
	candidates=[os.environ.get('OSGEO4W_ROOT'),'C:\\OSGeo4W','C:\\OSGeo4W64']
	for root in candidates:
		if root and os.path.isdir(root):return root
def find_python_qgis_bat(root):
	if not root:return
	bin_dir=os.path.join(root,'bin');ltr=os.path.join(bin_dir,'python-qgis-ltr.bat');normal=os.path.join(bin_dir,'python-qgis.bat')
	if os.path.isfile(ltr):return'python-qgis-ltr.bat'
	if os.path.isfile(normal):return'python-qgis.bat'
def find_qgis_app_path():
	candidates=['/Applications/QGIS-LTR.app','/Applications/QGIS.app']
	for app in candidates:
		if os.path.isdir(app):return app
def build_installation_guidance(missing_import_names):
	if not missing_import_names:return''
	pip_names=[]
	for imp in missing_import_names:pip_names.append(PIP_NAME_MAP.get(imp,imp))
	pip_install_str=' '.join(pip_names)
	if OS_NAME=='Windows':
		root=find_osgeo4w_root();python_bat=find_python_qgis_bat(root)if root else None
		if root and python_bat:guidance=rf"""
<h3>Windows – QGIS (OSGeo4W)</h3>

<ol>
<li>Press the <b>Windows key</b> and search for <b>“OSGeo4W Shell”</b>.</li>
<li>Open <b>OSGeo4W Shell</b> (NOT the regular Command Prompt).</li>
<li>Run the following commands:</li>
</ol>

<pre>
cd {root}
call bin\o4w_env.bat
call bin\{python_bat} -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> The Python launcher inside QGIS may be named
<b>python-qgis-ltr.bat</b> or <b>python-qgis.bat</b>,
depending on your installation.</p>

<p><i>Note:</i> Your OSGeo4W installation folder may also be named
<b>OSGeo4W</b>, <b>OSGeo4W64</b>, or a custom path
(e.g. inside Program Files or AppData).</p>
"""
		else:guidance=f"""
<h3>Windows – QGIS (OSGeo4W)</h3>

OSGeo4W installation folder could not be automatically detected.

<ol>
<li>Open <b>OSGeo4W Shell</b>.</li>
<li>Navigate to your OSGeo4W installation directory.</li>
<li>Run:</li>
</ol>

<pre>
call bin\\python-qgis-ltr.bat -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> The launcher may also be named <b>python-qgis.bat</b>.</p>
"""
		tips_section=f"""
<hr>
<h3>⚠ Tips and pitfalls.</h3>
<b>Please read and use this additional guidance.</b>
<hr>

<ul>
<li>Always use <b>OSGeo4W Shell</b> on Windows. Do NOT use the regular Command Prompt.</li>
<li>Make sure you are installing packages into the <b>same Python environment</b> used by QGIS.</li>
<li>If installation fails, try upgrading pip first:</li>
</ul>

<pre>
python -m pip install --upgrade pip
</pre>

<ul>
<li>If multiple QGIS versions are installed, ensure you are using the correct LTR environment.</li>
<li>After installation, completely close and restart QGIS.</li>
</ul>
""";return guidance+tips_section
	elif OS_NAME=='Darwin':
		app_path=find_qgis_app_path()
		if app_path:mac_bin=os.path.join(app_path,'Contents','MacOS');guidance=f'''
<h3>macOS – QGIS.app</h3>

<ol>
<li>Open <b>Terminal</b>.</li>
<li>Run the following commands:</li>
</ol>

<pre>
cd "{mac_bin}"
./bin/python3 -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> Your QGIS application may be named
<b>QGIS-LTR.app</b> or <b>QGIS.app</b>,
depending on the installed version.</p>

<p><i>Important:</i> Make sure you are using the Python environment
inside QGIS.app, not the system Python.</p>
'''
		else:guidance=f"""
<h3>macOS – QGIS.app</h3>

QGIS installation folder could not be automatically detected automatically.

<ol>
<li>Open <b>Terminal</b>.</li>
<li>Locate your QGIS installation (usually inside /Applications).</li>
<li>Navigate to:</li>
</ol>

<pre>
/Applications/QGIS-LTR.app/Contents/MacOS
</pre>

<p>If unsure, try both:</p>

<pre>
/Applications/QGIS-LTR.app/Contents/MacOS
/Applications/QGIS.app/Contents/MacOS
</pre>

<p>Then run:</p>

<pre>
./bin/python3 -m pip install {pip_install_str}
</pre>

<p><i>Important:</i> Do NOT use the system Python (python3)
outside QGIS.app, as packages would be installed in the wrong environment.</p>
"""
		tips_section=f"""
<hr>
<h3>⚠ Tips and pitfalls.</h3>
<b>Please read and use this additional guidance.</b>
<hr>

<ul>
<li>Always install packages inside the <b>QGIS.app Python environment</b>.</li>
<li>Do NOT use the default macOS Python environment.</li>
<li>If installation fails, try upgrading pip first:</li>
</ul>

<pre>
./bin/python3 -m pip install --upgrade pip
</pre>

<ul>
<li>If you have multiple QGIS versions installed, ensure you are using the correct LTR version.</li>
<li>After installation, completely close and restart QGIS.</li>
</ul>
""";return guidance+tips_section
	else:return f"""
<h3>Python Environment</h3>

<pre>
python3 -m pip install {pip_install_str}
</pre>
"""
class EnvironmentAssessmentDialog(QDialog):
	def __init__(self,parent=None):
		super().__init__(parent);self.setWindowTitle('geoQguide – Environment Assessment');self.resize(720,600);layout=QVBoxLayout(self);title=QLabel('<b>Required Python Libraries</b>');layout.addWidget(title);results=scan_required_libraries();content_html="<div style='font-size:13px;'>";missing=[]
		for(lib,ok)in results.items():
			symbol='✅'if ok else'❌';content_html+=f"{symbol} {lib}<br>"
			if not ok:missing.append(lib)
		content_html+='<br>'
		if not missing:content_html+='<b>All key required libraries are available.</b>'
		else:content_html+='<b>⚠ Some required libraries are missing.</b><br>Please follow the installation instructions below.';content_html+='<hr>';content_html+=build_installation_guidance(missing)
		content_html+='</div>';scroll=QScrollArea();scroll.setWidgetResizable(True);container=QWidget();v=QVBoxLayout(container);browser=QTextBrowser();browser.setHtml(content_html);browser.setOpenExternalLinks(True);v.addWidget(browser);scroll.setWidget(container);layout.addWidget(scroll);QgsMessageLog.logMessage('[Environment] Assessment completed.','GeoQGuide',Qgis.Info)
def show_environment_assessment(parent=None):dlg=EnvironmentAssessmentDialog(parent=parent);dlg.exec_()
def main(local=None):_=_resolve_local_dir(local);show_environment_assessment(parent=iface.mainWindow()if iface else None)
if GQG_AUTO_RUN and __name__ in('__main__','__console__'):
	try:main(local=None)
	except Exception as e:QgsMessageLog.logMessage(f"[Environment] Failed to open assessment dialog: {e}",'GeoQGuide',Qgis.Critical)