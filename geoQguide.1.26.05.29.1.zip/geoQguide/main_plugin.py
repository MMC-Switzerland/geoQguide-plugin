import os
from.settings_manager import SettingsManager
_HERE=os.path.dirname(os.path.abspath(__file__))
class GeoQguidePlugin:
	def __init__(A,iface):A.iface=iface;A._action=None;A._runner=None;A._api_client=None;A.settings=SettingsManager();A.settings.write_defaults()
	def initGui(A):from qgis.PyQt.QtWidgets import QAction as C;A._action=C('geoQguide',A.iface.mainWindow());A._action.triggered.connect(A.run);A.iface.addPluginToMenu('geoQguide',A._action);from.version_check import schedule_check as D;import configparser as E,os;B=E.ConfigParser();B.read(os.path.join(_HERE,'metadata.txt'));F=B.get('general','version',fallback='0');D(F,A.iface)
	def unload(A):A.iface.removePluginMenu('geoQguide',A._action);A._action=None;A._runner=None
	def _get_runner(A):
		if A._runner is None:from.runner import ScriptRunner as B;A._runner=B(bundle_path=os.path.join(_HERE,'bundle.tar.gz.enc'),api_client=A._api_client)
		return A._runner
	def _get_api_client(A):
		if A._api_client is None:
			import traceback as C
			try:from.api_client import GeoQGuideApiClient as D;E=A.settings.read();A._api_client=D(base_url=E.api_base_url)
			except Exception:
				B=C.format_exc();print(f"[geoQguide] FATAL — could not initialise API client:\n{B}")
				try:from qgis.core import QgsMessageLog as F,Qgis;F.logMessage(f"FATAL — could not initialise API client:\n{B}",'geoQguide',Qgis.Critical)
				except Exception:pass
				raise
		return A._api_client
	def run(B):
		import traceback as C;D=None;A=''
		try:D=B._get_api_client()
		except Exception:A=C.format_exc()
		E=None
		try:E=B._get_runner()
		except Exception:
			if not A:A=C.format_exc()
		from.launcher_dialog import launch as F;F(runner=E,settings_manager=B.settings,api_client=D,api_client_error=A)