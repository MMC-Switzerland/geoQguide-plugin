from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from .. import types
from ..types import UNSET, File, Unset

T = TypeVar("T", bound="ProcessRecognitionPreviewBody")


@_attrs_define
class ProcessRecognitionPreviewBody:
    """
    Attributes:
        data_source_uri (str): The QGIS data source URI of the layer Example: contextualWMSLegend=0&crs=EPSG:32632&dpiMo
            de=7&featureCount=10&format=image/png&layers=ulter_cont_unesco&styles&tilePixelRatio=0&url=http://www502.regione
            .toscana.it/wmsraster/com.rt.wms.RTmap/wms?map%3Dwmspiapae%26map_resolution%3D91.
        items (str): JSON array with the metadata of every legend item, in the same order as the uploaded images. Each
            element supports name (string, required), description (string, required), isBackground (boolean, optional,
            defaults to false) and itemClass (string, optional, one of NoAction, ReferenceOnly, RiskOrCost, NotUsable,
            defaults to NoAction). Example: [{"name":"Forest","description":"Dense forest
            cover","isBackground":false,"itemClass":"RiskOrCost"},{"name":"Water","description":"Open water
            bodies","isBackground":true,"itemClass":"NoAction"}].
        images (list[File]): Image files of the legend items. Provide one file per element of the 'items' array, in the
            same order.
        map_image (File): Map image file (PNG, JPEG, etc.)
        area_px (Union[Unset, str]): Optional recognition area in pixel coordinates of mapImage, as a JSON polygon with
            [x, y] positions. No coordinate conversion happens anywhere in this endpoint. Omit it to analyze the whole
            image. Example: {"type":"Polygon","coordinates":[[[0,0],[800,0],[800,600],[0,600],[0,0]]]}.
    """

    data_source_uri: str
    items: str
    images: list[File]
    map_image: File
    area_px: Union[Unset, str] = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        data_source_uri = self.data_source_uri

        items = self.items

        images = []
        for images_item_data in self.images:
            images_item = images_item_data.to_tuple()

            images.append(images_item)

        map_image = self.map_image.to_tuple()

        area_px = self.area_px

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "dataSourceUri": data_source_uri,
                "items": items,
                "images": images,
                "mapImage": map_image,
            }
        )
        if area_px is not UNSET:
            field_dict["areaPx"] = area_px

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("dataSourceUri", (None, str(self.data_source_uri).encode(), "text/plain")))

        files.append(("items", (None, str(self.items).encode(), "text/plain")))

        for images_item_element in self.images:
            files.append(("images", images_item_element.to_tuple()))

        files.append(("mapImage", self.map_image.to_tuple()))

        if not isinstance(self.area_px, Unset):
            files.append(("areaPx", (None, str(self.area_px).encode(), "text/plain")))

        for prop_name, prop in self.additional_properties.items():
            files.append((prop_name, (None, str(prop).encode(), "text/plain")))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        data_source_uri = d.pop("dataSourceUri")

        items = d.pop("items")

        images = []
        _images = d.pop("images")
        for images_item_data in _images:
            images_item = File(payload=BytesIO(images_item_data))

            images.append(images_item)

        map_image = File(payload=BytesIO(d.pop("mapImage")))

        area_px = d.pop("areaPx", UNSET)

        process_recognition_preview_body = cls(
            data_source_uri=data_source_uri,
            items=items,
            images=images,
            map_image=map_image,
            area_px=area_px,
        )

        process_recognition_preview_body.additional_properties = d
        return process_recognition_preview_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
