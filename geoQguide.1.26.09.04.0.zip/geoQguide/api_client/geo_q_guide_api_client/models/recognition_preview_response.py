from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="RecognitionPreviewResponse")


@_attrs_define
class RecognitionPreviewResponse:
    """
    Attributes:
        width (Union[Unset, int]):
        height (Union[Unset, int]):
        format_ (Union[None, Unset, str]):
        outside_value (Union[Unset, int]):
        unrecognized_value (Union[Unset, int]):
        first_item_value (Union[Unset, int]):
        data (Union[None, Unset, str]):
    """

    width: Union[Unset, int] = UNSET
    height: Union[Unset, int] = UNSET
    format_: Union[None, Unset, str] = UNSET
    outside_value: Union[Unset, int] = UNSET
    unrecognized_value: Union[Unset, int] = UNSET
    first_item_value: Union[Unset, int] = UNSET
    data: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        width = self.width

        height = self.height

        format_: Union[None, Unset, str]
        if isinstance(self.format_, Unset):
            format_ = UNSET
        else:
            format_ = self.format_

        outside_value = self.outside_value

        unrecognized_value = self.unrecognized_value

        first_item_value = self.first_item_value

        data: Union[None, Unset, str]
        if isinstance(self.data, Unset):
            data = UNSET
        else:
            data = self.data

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if width is not UNSET:
            field_dict["width"] = width
        if height is not UNSET:
            field_dict["height"] = height
        if format_ is not UNSET:
            field_dict["format"] = format_
        if outside_value is not UNSET:
            field_dict["outsideValue"] = outside_value
        if unrecognized_value is not UNSET:
            field_dict["unrecognizedValue"] = unrecognized_value
        if first_item_value is not UNSET:
            field_dict["firstItemValue"] = first_item_value
        if data is not UNSET:
            field_dict["data"] = data

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        width = d.pop("width", UNSET)

        height = d.pop("height", UNSET)

        def _parse_format_(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        format_ = _parse_format_(d.pop("format", UNSET))

        outside_value = d.pop("outsideValue", UNSET)

        unrecognized_value = d.pop("unrecognizedValue", UNSET)

        first_item_value = d.pop("firstItemValue", UNSET)

        def _parse_data(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        data = _parse_data(d.pop("data", UNSET))

        recognition_preview_response = cls(
            width=width,
            height=height,
            format_=format_,
            outside_value=outside_value,
            unrecognized_value=unrecognized_value,
            first_item_value=first_item_value,
            data=data,
        )

        return recognition_preview_response
