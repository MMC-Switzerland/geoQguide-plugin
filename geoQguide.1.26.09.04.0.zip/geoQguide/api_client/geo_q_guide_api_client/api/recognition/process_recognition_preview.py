from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.process_recognition_preview_body import ProcessRecognitionPreviewBody
from ...models.recognition_preview_response import RecognitionPreviewResponse
from ...types import Response


def _get_kwargs(
    *,
    body: ProcessRecognitionPreviewBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/recognition/preview",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, RecognitionPreviewResponse]]:
    if response.status_code == 200:
        response_200 = RecognitionPreviewResponse.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, RecognitionPreviewResponse]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ProcessRecognitionPreviewBody,
) -> Response[Union[Any, RecognitionPreviewResponse]]:
    """Preview recognition with a legend submitted in the request

     Classifies a provided map image against a legend that is submitted with the request and never
    stored. Send the item metadata as a JSON array in the 'items' field and the matching image files as
    repeated 'images' file fields, in the same order. The answer is the classification itself: one byte
    per pixel of the submitted map image, aligned with it one to one, where a pixel holds firstItemValue
    + the zero based index of the item within the submitted 'items' array, unrecognizedValue when it
    matched no item closely enough, or outsideValue when it is outside the recognition area or matched a
    background item. Nothing is converted to a coordinate system on the way, so the caller keeps
    ownership of the georeferencing of the image it uploaded and vectorizes the mask itself.

    Args:
        body (ProcessRecognitionPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, RecognitionPreviewResponse]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ProcessRecognitionPreviewBody,
) -> Optional[Union[Any, RecognitionPreviewResponse]]:
    """Preview recognition with a legend submitted in the request

     Classifies a provided map image against a legend that is submitted with the request and never
    stored. Send the item metadata as a JSON array in the 'items' field and the matching image files as
    repeated 'images' file fields, in the same order. The answer is the classification itself: one byte
    per pixel of the submitted map image, aligned with it one to one, where a pixel holds firstItemValue
    + the zero based index of the item within the submitted 'items' array, unrecognizedValue when it
    matched no item closely enough, or outsideValue when it is outside the recognition area or matched a
    background item. Nothing is converted to a coordinate system on the way, so the caller keeps
    ownership of the georeferencing of the image it uploaded and vectorizes the mask itself.

    Args:
        body (ProcessRecognitionPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, RecognitionPreviewResponse]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ProcessRecognitionPreviewBody,
) -> Response[Union[Any, RecognitionPreviewResponse]]:
    """Preview recognition with a legend submitted in the request

     Classifies a provided map image against a legend that is submitted with the request and never
    stored. Send the item metadata as a JSON array in the 'items' field and the matching image files as
    repeated 'images' file fields, in the same order. The answer is the classification itself: one byte
    per pixel of the submitted map image, aligned with it one to one, where a pixel holds firstItemValue
    + the zero based index of the item within the submitted 'items' array, unrecognizedValue when it
    matched no item closely enough, or outsideValue when it is outside the recognition area or matched a
    background item. Nothing is converted to a coordinate system on the way, so the caller keeps
    ownership of the georeferencing of the image it uploaded and vectorizes the mask itself.

    Args:
        body (ProcessRecognitionPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, RecognitionPreviewResponse]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: ProcessRecognitionPreviewBody,
) -> Optional[Union[Any, RecognitionPreviewResponse]]:
    """Preview recognition with a legend submitted in the request

     Classifies a provided map image against a legend that is submitted with the request and never
    stored. Send the item metadata as a JSON array in the 'items' field and the matching image files as
    repeated 'images' file fields, in the same order. The answer is the classification itself: one byte
    per pixel of the submitted map image, aligned with it one to one, where a pixel holds firstItemValue
    + the zero based index of the item within the submitted 'items' array, unrecognizedValue when it
    matched no item closely enough, or outsideValue when it is outside the recognition area or matched a
    background item. Nothing is converted to a coordinate system on the way, so the caller keeps
    ownership of the georeferencing of the image it uploaded and vectorizes the mask itself.

    Args:
        body (ProcessRecognitionPreviewBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, RecognitionPreviewResponse]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
