from __future__ import annotations
import os,platform,importlib.util,inspect,html as _html
from typing import List,Dict,Optional
from qgis.PyQt.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QScrollArea,QWidget,QTextBrowser,QPushButton,QPlainTextEdit,QApplication,QMessageBox
from qgis.PyQt.QtCore import Qt,QThread,pyqtSignal
from qgis.PyQt.QtGui import QFont
from qgis.core import QgsMessageLog,Qgis
try:from qgis.utils import iface
except Exception:iface=globals().get('iface',None)
GQG_AUTO_RUN=globals().get('GQG_AUTO_RUN',True)
GQG_LOCAL_DIR=globals().get('GQG_LOCAL_DIR',None)
def log(msg,level=Qgis.Info):
	try:print(f"[Environment] {msg}")
	except Exception:pass
	try:QgsMessageLog.logMessage(str(msg),'GeoQGuide',level)
	except Exception:pass
	if iface:
		try:iface.messageBar().pushMessage('GeoQGuide',str(msg),level=0,duration=4)
		except Exception:pass
def _resolve_local_dir(local=None):
	if local and os.path.isdir(local):return local
	if GQG_LOCAL_DIR and os.path.isdir(GQG_LOCAL_DIR):return GQG_LOCAL_DIR
	try:
		here=os.path.dirname(inspect.stack()[0].filename)
		if here and os.path.isdir(here):return here
	except Exception:pass
	return os.getcwd()
REQUIRED_LIBRARIES=['numpy','PIL','skimage','requests','duckdb','docx','httpx','attrs','matplotlib','cryptography','dateutil']
PIP_NAME_MAP={'PIL':'pillow','skimage':'scikit-image','docx':'python-docx','dateutil':'python-dateutil'}
OS_NAME=platform.system()
def is_library_available(pkg_name):
	try:return importlib.util.find_spec(pkg_name)is not None
	except Exception:return False
def scan_required_libraries():
	results={}
	for lib in REQUIRED_LIBRARIES:results[lib]=is_library_available(lib)
	return results
def find_osgeo4w_root():
	candidates=[os.environ.get('OSGEO4W_ROOT'),'C:\\OSGeo4W','C:\\OSGeo4W64']
	for root in candidates:
		if root and os.path.isdir(root):return root
def find_python_qgis_bat(root):
	if not root:return
	bin_dir=os.path.join(root,'bin');ltr=os.path.join(bin_dir,'python-qgis-ltr.bat');normal=os.path.join(bin_dir,'python-qgis.bat')
	if os.path.isfile(ltr):return'python-qgis-ltr.bat'
	if os.path.isfile(normal):return'python-qgis.bat'
def find_qgis_app_path():
	candidates=['/Applications/QGIS-LTR.app','/Applications/QGIS.app']
	for app in candidates:
		if os.path.isdir(app):return app
def find_qgis_python_path():
	import sys,sysconfig,glob;_skip_ext='.dll','.dylib','.so','.a','.py','.pyc','.lib','.exp';ver=f"{sys.version_info.major}.{sys.version_info.minor}";bin_names=['python3',f"python{ver}",f"python{sys.version_info.major}",'python']
	def _is_real_binary(path):
		if not path or not os.path.isfile(path):return False
		if path.lower().endswith(_skip_ext):return False
		return True
	def _probe_dir(d):
		if not d or not os.path.isdir(d):return
		for name in bin_names:
			cand=os.path.join(d,name)
			if _is_real_binary(cand):return cand
	prefix_dirs=[]
	for attr in('prefix','exec_prefix','base_prefix','base_exec_prefix'):
		val=getattr(sys,attr,None)
		if val:prefix_dirs.append(os.path.join(val,'bin'))
	for d in prefix_dirs:
		found=_probe_dir(d)
		if found:return found
	try:
		found=_probe_dir(sysconfig.get_config_var('BINDIR'))
		if found:return found
	except Exception:pass
	try:
		found=_probe_dir(sysconfig.get_path('scripts'))
		if found:return found
	except Exception:pass
	base_exe=getattr(sys,'_base_executable','')or''
	if _is_real_binary(base_exe)and'python'in os.path.basename(base_exe).lower():return base_exe
	exe=sys.executable or'';app_root=None
	if exe and'.app/'in exe:idx=exe.find('.app/');app_root=exe[:idx+4]
	if not app_root or not os.path.isdir(app_root):app_root=find_qgis_app_path()
	if not app_root:return
	glob_patterns=[os.path.join(app_root,'Contents','MacOS','python3*'),os.path.join(app_root,'Contents','MacOS','bin','python3*'),os.path.join(app_root,'Contents','Frameworks','Python.framework','Versions','*','bin','python3*'),os.path.join(app_root,'Contents','Resources','python','bin','python3*')]
	for pattern in glob_patterns:
		for match in sorted(glob.glob(pattern),reverse=True):
			if _is_real_binary(match):return match
	try:
		rec=os.path.join(app_root,'Contents','**','python3*')
		for match in sorted(glob.glob(rec,recursive=True)):
			if _is_real_binary(match)and os.access(match,os.X_OK):return match
	except Exception:pass
def build_macos_environment_info():
	app_path=find_qgis_app_path();python_path=find_qgis_python_path();html='<hr><h3>macOS – QGIS Python Environment Info</h3>'
	if python_path:python_dir=os.path.dirname(python_path);html+=f"""
<p><b>Detected QGIS Python binary:</b></p>
<pre>{python_path}</pre>

<p><b>QGIS Python folder:</b></p>
<pre>{python_dir}</pre>

<p>This is the Python interpreter that QGIS uses internally.
All pip commands must target this specific Python.</p>
"""
	elif app_path:mac_bin=os.path.join(app_path,'Contents','MacOS','bin');html+=f"""
<p><b>QGIS app detected at:</b> {app_path}</p>
<p><b>Expected Python folder:</b></p>
<pre>{mac_bin}</pre>

<p>⚠ Could not confirm the Python binary exists at this location.
Check inside the folder above for <code>python3</code> or <code>python3.X</code>.</p>
"""
	else:html+='\n<p>⚠ Could not detect a QGIS installation in /Applications.</p>\n<p>Common locations to check:</p>\n<pre>\n/Applications/QGIS-LTR.app/Contents/MacOS/bin/python3\n/Applications/QGIS.app/Contents/MacOS/bin/python3\n</pre>\n<p>If QGIS was installed via Homebrew, check under\n<code>/opt/homebrew/</code> or <code>/usr/local/</code> instead.</p>\n'
	html+=build_python_diagnostics_html();html+='\n<hr>\n<h3>Clearing QGIS HTTP Cache (macOS)</h3>\n\n<p>If you experience stale data, authentication issues, or network errors,\nclear the QGIS HTTP cache by running these commands in <b>Terminal</b>:</p>\n\n<pre>\nrm -rf ~/Library/Caches/org.qgis*\nrm -rf "$HOME/Library/Application Support/QGIS/QGIS3/profiles/default/cache"\n</pre>\n\n<p><i>Note:</i> After clearing the cache, restart QGIS completely.</p>\n<p><i>Note:</i> If you use a non-default QGIS profile, replace\n<code>default</code> with your profile name in the path above.</p>\n';return html
def build_python_diagnostics_html():
	import sys,sysconfig,glob;rows=[]
	def add(label,value):rows.append(f"<tr><td style='padding:2px 10px 2px 0;vertical-align:top;'><b>{label}</b></td><td style='padding:2px 0;'><code>{value}</code></td></tr>")
	try:add('sys.executable',sys.executable or'(empty)')
	except Exception:pass
	candidate_dirs=[]
	for attr in('prefix','exec_prefix','base_prefix','base_exec_prefix'):
		try:
			val=getattr(sys,attr,None)
			if val:add(f"sys.{attr}",str(val));candidate_dirs.append(os.path.join(val,'bin'));candidate_dirs.append(val)
		except Exception:pass
	try:
		bindir=sysconfig.get_config_var('BINDIR');add('sysconfig BINDIR',str(bindir))
		if bindir:candidate_dirs.append(bindir)
	except Exception:pass
	try:
		exe=sys.executable or''
		if exe and'.app/'in exe:macos_dir=os.path.dirname(exe);add('QGIS Contents/MacOS',macos_dir);candidate_dirs.append(macos_dir)
	except Exception:pass
	try:add('Python version',sys.version.split()[0])
	except Exception:pass
	found_binaries=[];seen=set();_skip_ext='.dll','.dylib','.so','.a','.py','.pyc','.lib','.exp'
	try:
		for d in candidate_dirs:
			if not d or d in seen or not os.path.isdir(d):continue
			seen.add(d)
			for match in sorted(glob.glob(os.path.join(d,'python3*'))):
				if not os.path.isfile(match):continue
				if match.lower().endswith(_skip_ext):continue
				try:
					if not os.access(match,os.X_OK):continue
				except Exception:pass
				if match not in found_binaries:found_binaries.append(match)
	except Exception:pass
	html='<hr><h3>Live Python Diagnostics (authoritative)</h3>';html+='<p>The values below are read directly from the Python interpreter running inside QGIS right now. Use these if the detected path above does not work.</p>';html+="<table style='border-collapse:collapse;'>"+''.join(rows)+'</table>'
	if found_binaries:html+='<p><b>Python binaries found on disk:</b></p><pre>';html+='\n'.join(found_binaries);html+='</pre>';html+='<p>Use the topmost path above as your Python for pip commands.</p>'
	else:html+="<p>⚠ No <code>python3*</code> binary was found in the locations above. If pip commands fail, open the QGIS <b>Python Console</b> (Plugins → Python Console) and run:</p><pre>import sys, os\nfor d in (sys.prefix, sys.exec_prefix, sys.base_prefix):\n    b = os.path.join(d, 'bin')\n    print(b, '->', os.path.isdir(b) and os.listdir(b))</pre><p>Then use whichever <code>python3</code> entry is listed.</p>"
	return html
def _to_pip_names(missing_import_names):
	out=[]
	for imp in missing_import_names:out.append(PIP_NAME_MAP.get(imp,imp))
	return out
def _import_pip_main():
	import importlib
	for(mod,attr)in(('pip._internal.cli.main','main'),('pip._internal','main'),('pip','main')):
		try:
			m=importlib.import_module(mod);fn=getattr(m,attr,None)
			if callable(fn):return fn
		except Exception:continue
def _ensure_pip(emit):
	fn=_import_pip_main()
	if fn:emit('pip is available.');return fn
	emit('pip is not importable — attempting ensurepip.bootstrap() ...')
	try:import ensurepip;ensurepip.bootstrap();emit('ensurepip.bootstrap() completed.')
	except Exception as e:emit(f"ensurepip.bootstrap() FAILED: {e!r}")
	try:import importlib;importlib.invalidate_caches()
	except Exception:pass
	fn=_import_pip_main();emit('pip is now available.'if fn else'pip STILL unavailable after bootstrap.');return fn
class _EmitStream:
	def __init__(self,emit):self._emit=emit;self._buf=''
	def write(self,s):
		try:
			if not isinstance(s,str):s=str(s)
			self._buf+=s
			while'\n'in self._buf:line,self._buf=self._buf.split('\n',1);self._emit(line.rstrip('\r'))
		except Exception:pass
		try:return len(s)
		except Exception:return 0
	def flush(self):
		try:
			if self._buf:self._emit(self._buf.rstrip('\r'));self._buf=''
		except Exception:pass
	def isatty(self):return False
def run_pip_install(pip_names,emit):
	import sys,site,contextlib,importlib,datetime
	def section(title):emit('');emit('='*60);emit(title);emit('='*60)
	section('geoQguide — In-process library installation')
	try:emit(f"Timestamp        : {datetime.datetime.now().isoformat(timespec="seconds")}")
	except Exception:pass
	try:emit(f"Packages         : {" ".join(pip_names)if pip_names else"(none)"}")
	except Exception:pass
	try:emit(f"OS               : {platform.platform()}")
	except Exception:pass
	try:emit(f"Python version   : {sys.version.split()[0]}")
	except Exception:pass
	for attr in('executable','prefix','exec_prefix','base_prefix'):
		try:emit(f"sys.{attr:<12} : {getattr(sys,attr,"?")}")
		except Exception:pass
	try:
		sp=[]
		try:sp=list(site.getsitepackages())
		except Exception:pass
		try:
			usp=site.getusersitepackages()
			if usp:sp.append(usp)
		except Exception:pass
		if not sp:emit('site-packages    : (could not determine)')
		for d in sp:
			try:emit(f"site-packages    : [{"writable"if os.access(d,os.W_OK)else"read-only"}] {d}")
			except Exception:emit(f"site-packages    : {d}")
	except Exception as e:emit(f"site-packages    : (error) {e!r}")
	if not pip_names:emit('No packages to install. Nothing to do.');return True,0
	pip_main=_ensure_pip(emit)
	if pip_main is None:emit('ERROR: pip is not available and could not be bootstrapped.');return False,-1
	base_args=['install','--disable-pip-version-check','--no-input',*pip_names]
	def _run(args):
		emit('');emit(f"Running: pip {" ".join(args)}");stream=_EmitStream(emit);code=1
		try:
			with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):
				try:ret=pip_main(list(args));code=0 if ret is None else int(ret)
				except SystemExit as se:
					try:code=int(se.code)if se.code is not None else 0
					except Exception:code=1
		except Exception as e:emit(f"EXCEPTION during pip run: {e!r}");code=1
		finally:
			try:stream.flush()
			except Exception:pass
		emit(f"pip return code  : {code}");return code
	code=_run(base_args)
	if code!=0:section('First attempt failed — retrying with --user (permission fallback)');code=_run(base_args+['--user'])
	success=code==0;section('Result')
	try:importlib.invalidate_caches()
	except Exception:pass
	emit(f"Final result     : {"SUCCESS"if success else"FAILED"} (code {code})")
	if success:emit('Please RESTART QGIS to load the newly installed libraries.')
	else:emit('Installation failed. Review the log above, or use the manual script.')
	return success,code
def build_inprocess_install_snippet(pip_names):pkgs=', '.join(f'"{p}"'for p in pip_names)if pip_names else'';return f'''# geoQguide - install missing Python libraries
# 1) Open QGIS: Plugins -> Python Console
# 2) Paste this ENTIRE block and press Enter
# 3) When it finishes, RESTART QGIS
import importlib

def _pip_main():
    for mod, attr in (("pip._internal.cli.main", "main"),
                      ("pip._internal", "main"),
                      ("pip", "main")):
        try:
            m = importlib.import_module(mod)
            fn = getattr(m, attr, None)
            if callable(fn):
                return fn
        except Exception:
            pass
    return None

pip_main = _pip_main()
if pip_main is None:
    import ensurepip
    ensurepip.bootstrap()
    importlib.invalidate_caches()
    pip_main = _pip_main()

pkgs = [{pkgs}]
args = ["install", "--disable-pip-version-check", "--no-input", *pkgs]
try:
    code = pip_main(args)
    print("pip return code:", code)
except SystemExit as e:
    # pip calls sys.exit(); swallow it so QGIS stays open
    print("pip finished (SystemExit), code:", e.code)
print("Done. Please RESTART QGIS to load the new libraries.")
'''
def build_inprocess_section_html(pip_names):script=build_inprocess_install_snippet(pip_names);return'<hr><h3>✅ Recommended: install inside QGIS (works on all systems)</h3><p>The most reliable method — especially on macOS — is to install the libraries <b>inside the running QGIS Python</b>. You have two options:</p><ul><li><b>Easiest:</b> click the <b>Install</b> button at the top of this window.</li><li><b>Manual:</b> open the QGIS <b>Python Console</b> (Plugins → Python Console) and paste the script below.</li></ul><pre>'+_html.escape(script)+'</pre><p>After it finishes, <b>restart QGIS</b> so the new libraries load.</p>'
class _PipInstallWorker(QThread):
	log_line=pyqtSignal(str);done=pyqtSignal(bool,int)
	def __init__(self,pip_names,parent=None):super().__init__(parent);self._pip_names=list(pip_names)
	def run(self):
		try:ok,code=run_pip_install(self._pip_names,self.log_line.emit)
		except Exception as e:
			try:self.log_line.emit(f"FATAL worker error: {e!r}")
			except Exception:pass
			ok,code=False,-1
		self.done.emit(bool(ok),int(code))
def build_installation_guidance(missing_import_names):
	if not missing_import_names:return''
	pip_names=[]
	for imp in missing_import_names:pip_names.append(PIP_NAME_MAP.get(imp,imp))
	pip_install_str=' '.join(pip_names)
	if OS_NAME=='Windows':
		root=find_osgeo4w_root();python_bat=find_python_qgis_bat(root)if root else None
		if root and python_bat:guidance=rf"""
<h3>Windows – QGIS (OSGeo4W)</h3>

<ol>
<li>Press the <b>Windows key</b> and search for <b>“OSGeo4W Shell”</b>.</li>
<li>Open <b>OSGeo4W Shell</b> (NOT the regular Command Prompt).</li>
<li>Run the following commands:</li>
</ol>

<pre>
cd {root}
call bin\o4w_env.bat
call bin\{python_bat} -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> The Python launcher inside QGIS may be named
<b>python-qgis-ltr.bat</b> or <b>python-qgis.bat</b>,
depending on your installation.</p>

<p><i>Note:</i> Your OSGeo4W installation folder may also be named
<b>OSGeo4W</b>, <b>OSGeo4W64</b>, or a custom path
(e.g. inside Program Files or AppData).</p>
"""
		else:guidance=f"""
<h3>Windows – QGIS (OSGeo4W)</h3>

OSGeo4W installation folder could not be automatically detected.

<ol>
<li>Open <b>OSGeo4W Shell</b>.</li>
<li>Navigate to your OSGeo4W installation directory.</li>
<li>Run:</li>
</ol>

<pre>
call bin\\python-qgis-ltr.bat -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> The launcher may also be named <b>python-qgis.bat</b>.</p>
"""
		tips_section=f"""
<hr>
<h3>⚠ Tips and pitfalls.</h3>
<b>Please read and use this additional guidance.</b>
<hr>

<ul>
<li>Always use <b>OSGeo4W Shell</b> on Windows. Do NOT use the regular Command Prompt.</li>
<li>Make sure you are installing packages into the <b>same Python environment</b> used by QGIS.</li>
<li>If installation fails, try upgrading pip first:</li>
</ul>

<pre>
python -m pip install --upgrade pip
</pre>

<ul>
<li>If multiple QGIS versions are installed, ensure you are using the correct LTR environment.</li>
<li>After installation, completely close and restart QGIS.</li>
</ul>
""";return guidance+tips_section
	elif OS_NAME=='Darwin':
		app_path=find_qgis_app_path();python_path=find_qgis_python_path()
		if python_path:python_dir=os.path.dirname(python_path);guidance=f'''
<h3>macOS – QGIS.app</h3>

<p><b>Detected QGIS Python:</b></p>
<pre>{python_path}</pre>

<ol>
<li>Open <b>Terminal</b>.</li>
<li>Run the following command:</li>
</ol>

<pre>
"{python_path}" -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> Your QGIS application may be named
<b>QGIS-LTR.app</b> or <b>QGIS.app</b>,
depending on the installed version.</p>

<p><i>Important:</i> Make sure you are using the Python environment
inside QGIS.app, not the system Python.</p>
'''
		elif app_path:mac_bin=os.path.join(app_path,'Contents','MacOS');guidance=f'''
<h3>macOS – QGIS.app</h3>

<p><b>QGIS app detected at:</b> {app_path}</p>
<p><b>Expected Python folder:</b> {mac_bin}/bin/</p>
<p>⚠ Could not confirm the Python binary exists. Check the folder above
for <code>python3</code> or <code>python3.X</code>.</p>

<ol>
<li>Open <b>Terminal</b>.</li>
<li>Run the following commands:</li>
</ol>

<pre>
cd "{mac_bin}"
./bin/python3 -m pip install {pip_install_str}
</pre>

<p><i>Note:</i> Your QGIS application may be named
<b>QGIS-LTR.app</b> or <b>QGIS.app</b>,
depending on the installed version.</p>

<p><i>Important:</i> Make sure you are using the Python environment
inside QGIS.app, not the system Python.</p>
'''
		else:guidance=f"""
<h3>macOS – QGIS.app</h3>

<p>⚠ QGIS installation could not be automatically detected.</p>

<ol>
<li>Open <b>Terminal</b>.</li>
<li>Locate your QGIS installation (usually inside /Applications).</li>
<li>Navigate to the Python folder inside QGIS:</li>
</ol>

<pre>
/Applications/QGIS-LTR.app/Contents/MacOS
</pre>

<p>If unsure, try both:</p>

<pre>
/Applications/QGIS-LTR.app/Contents/MacOS
/Applications/QGIS.app/Contents/MacOS
</pre>

<p>Then run:</p>

<pre>
./bin/python3 -m pip install {pip_install_str}
</pre>

<p><i>Important:</i> Do NOT use the system Python (python3)
outside QGIS.app, as packages would be installed in the wrong environment.</p>

<p><i>If QGIS was installed via Homebrew,</i> the Python binary may be located under
<code>/opt/homebrew/</code> or <code>/usr/local/</code> instead.</p>
"""
		if python_path:pip_upgrade_cmd=f'"{python_path}" -m pip install --upgrade pip'
		else:pip_upgrade_cmd='./bin/python3 -m pip install --upgrade pip'
		tips_section=f"""
<hr>
<h3>⚠ Tips and pitfalls.</h3>
<b>Please read and use this additional guidance.</b>
<hr>

<ul>
<li>Always install packages inside the <b>QGIS.app Python environment</b>.</li>
<li>Do NOT use the default macOS Python environment
(<code>/usr/bin/python3</code> or Homebrew's <code>python3</code>).</li>
<li>If installation fails, try upgrading pip first:</li>
</ul>

<pre>
{pip_upgrade_cmd}
</pre>

<ul>
<li>If you have multiple QGIS versions installed, ensure you are using the correct LTR version.</li>
<li>After installation, completely close and restart QGIS.</li>
</ul>
""";mac_info=build_macos_environment_info();return guidance+tips_section+mac_info
	else:return f"""
<h3>Python Environment</h3>

<pre>
python3 -m pip install {pip_install_str}
</pre>
"""
class EnvironmentAssessmentDialog(QDialog):
	def __init__(self,parent=None):
		super().__init__(parent);self.setWindowTitle('geoQguide – Environment Assessment');self.resize(760,680);self._results={};self._missing=[];self._pip_names=[];self._worker=None;self._log_path=None;layout=QVBoxLayout(self);title=QLabel('<b>Required Python Libraries</b>');layout.addWidget(title);top=QHBoxLayout();self.install_btn=QPushButton('⬇  Install missing libraries automatically');self.install_btn.clicked.connect(self._on_install_clicked);self.status_label=QLabel('');self.status_label.setWordWrap(True);top.addWidget(self.install_btn);top.addWidget(self.status_label,1);layout.addLayout(top);scroll=QScrollArea();scroll.setWidgetResizable(True);container=QWidget();v=QVBoxLayout(container);self.browser=QTextBrowser();self.browser.setOpenExternalLinks(True);v.addWidget(self.browser);scroll.setWidget(container);layout.addWidget(scroll,1);log_label=QLabel("<b>Installation log</b> <span style='color:gray;'>(verbose, for troubleshooting)</span>");layout.addWidget(log_label);self.log_view=QPlainTextEdit();self.log_view.setReadOnly(True);self.log_view.setMaximumBlockCount(5000);self.log_view.setPlaceholderText('Installation output will appear here. A copy is also written to a log file and the QGIS Log Messages panel.')
		try:mono=QFont('Menlo');mono.setStyleHint(QFont.Monospace);mono.setPointSize(10);self.log_view.setFont(mono)
		except Exception:pass
		self.log_view.setMinimumHeight(160);layout.addWidget(self.log_view);self._refresh_status();QgsMessageLog.logMessage('[Environment] Assessment completed.','GeoQGuide',Qgis.Info)
	def _build_content_html(self):
		content_html="<div style='font-size:13px;'>"
		for(lib,ok)in self._results.items():symbol='✅'if ok else'❌';content_html+=f"{symbol} {lib}<br>"
		content_html+='<br>'
		if not self._missing:
			content_html+='<b>All key required libraries are available.</b>'
			if OS_NAME=='Darwin':content_html+=build_macos_environment_info()
		else:content_html+='<b>⚠ Some required libraries are missing.</b><br>Use the <b>Install</b> button above, or follow the instructions below.';content_html+='<hr>';content_html+=build_inprocess_section_html(self._pip_names);content_html+=build_installation_guidance(self._missing)
		content_html+='</div>';return content_html
	def _refresh_status(self):
		try:importlib.invalidate_caches()
		except Exception:pass
		self._results=scan_required_libraries();self._missing=[lib for(lib,ok)in self._results.items()if not ok];self._pip_names=_to_pip_names(self._missing)
		try:self.browser.setHtml(self._build_content_html())
		except Exception as e:QgsMessageLog.logMessage(f"[Environment] Failed to render content: {e!r}",'GeoQGuide',Qgis.Warning)
		installing=bool(self._worker and self._worker.isRunning())
		if installing:return
		if self._missing:self.install_btn.setEnabled(True);self.install_btn.setText('⬇  Install missing libraries automatically')
		else:self.install_btn.setEnabled(False);self.install_btn.setText('✅  All required libraries are installed')
	def _open_log_file(self):
		try:
			import tempfile,datetime;ts=datetime.datetime.now().strftime('%Y%m%d_%H%M%S');self._log_path=os.path.join(tempfile.gettempdir(),f"geoQguide_env_install_{ts}.log")
			with open(self._log_path,'a',encoding='utf-8')as f:f.write(f"# geoQguide environment install log ({ts})\n")
		except Exception:self._log_path=None
	def _append_log(self,line):
		try:self.log_view.appendPlainText(line)
		except Exception:pass
		try:
			if self._log_path:
				with open(self._log_path,'a',encoding='utf-8')as f:f.write(line+'\n')
		except Exception:pass
		try:QgsMessageLog.logMessage(line,'GeoQGuide',Qgis.Info)
		except Exception:pass
	def _on_install_clicked(self):
		if not self._missing:return
		if self._worker and self._worker.isRunning():return
		self.install_btn.setEnabled(False);self.install_btn.setText('⏳  Installing…');self.status_label.setText('Installing… this may take a few minutes. QGIS stays responsive.');self._open_log_file();self.log_view.clear();self._append_log(f"Starting installation of: {", ".join(self._pip_names)}")
		if self._log_path:self._append_log(f"Log file: {self._log_path}")
		self._worker=_PipInstallWorker(self._pip_names,self);self._worker.log_line.connect(self._append_log);self._worker.done.connect(self._on_install_done);self._worker.start()
	def _on_install_done(self,ok,code):
		self._append_log('');self._append_log(f"=== DONE: success={ok}, code={code} ===")
		if self._log_path:self._append_log(f"Full log saved to: {self._log_path}")
		self._refresh_status();still_missing=list(self._missing)
		if ok:self.status_label.setText('✅ Installation finished. Please RESTART QGIS to load the libraries.');self.install_btn.setEnabled(False);self.install_btn.setText('✅  Installed — restart QGIS');self._show_success_dialog(still_missing)
		else:self.status_label.setText(f"❌ Installation failed (code {code}). See the log below, or use the manual script in the panel above.");self.install_btn.setEnabled(True);self.install_btn.setText('⬇  Retry installing missing libraries');self._show_failure_dialog(code,still_missing)
	def _show_success_dialog(self,still_missing):
		try:
			box=QMessageBox(self);box.setIcon(QMessageBox.Information);box.setWindowTitle('geoQguide – Installation complete');box.setText('<b>Library installation finished successfully.</b>');info='You must <b>restart QGIS</b> now so the newly installed libraries are loaded.\n\nClose QGIS completely and open it again before using the plugin.'
			if still_missing:info+=f"\n\nNote: the following are still reported as missing in the current session and should become available after restart:\n{", ".join(still_missing)}"
			box.setInformativeText(info);box.setStandardButtons(QMessageBox.Ok);box.exec_()
		except Exception as e:QgsMessageLog.logMessage(f"[Environment] Could not show success dialog: {e!r}",'GeoQGuide',Qgis.Warning)
	def _show_failure_dialog(self,code,still_missing):
		try:
			missing_txt=', '.join(still_missing)if still_missing else'(unknown)';box=QMessageBox(self);box.setIcon(QMessageBox.Critical);box.setWindowTitle('geoQguide – Installation failed');box.setText('<b>The automatic installation did not complete.</b>');info=f"""Return code: {code}
Still missing: {missing_txt}

What you can do:
• Review the verbose log at the bottom of the window.
• Try the button again (it retries with a user-level install).
• Or copy the manual script shown in the window and run it in the QGIS Python Console (Plugins → Python Console)."""
			if self._log_path:info+=f"\n\nA full log was saved to:\n{self._log_path}"
			box.setInformativeText(info);box.setStandardButtons(QMessageBox.Ok);box.exec_()
		except Exception as e:QgsMessageLog.logMessage(f"[Environment] Could not show failure dialog: {e!r}",'GeoQGuide',Qgis.Warning)
	def closeEvent(self,event):
		try:
			if self._worker and self._worker.isRunning():self._append_log('Dialog closing — waiting for installer to finish…');self._worker.wait(3000)
		except Exception:pass
		super().closeEvent(event)
def show_environment_assessment(parent=None):dlg=EnvironmentAssessmentDialog(parent=parent);dlg.exec_()
def main(local=None):_=_resolve_local_dir(local);show_environment_assessment(parent=iface.mainWindow()if iface else None)
if GQG_AUTO_RUN and __name__ in('__main__','__console__'):
	try:main(local=None)
	except Exception as e:QgsMessageLog.logMessage(f"[Environment] Failed to open assessment dialog: {e}",'GeoQGuide',Qgis.Critical)