import os,builtins
from.bundle_loader import BundleLoader
class ScriptRunner:
	def __init__(A,local_dir='',bundle_path='',bundle_key=b'',bundle_url=''):B=bundle_path;A._bundle_path=B;A._bundle_url=bundle_url;A._etag_path=B+'.etag';A._loader=BundleLoader(B,bundle_key)
	def run(A,script_name,globals_dict=None):
		D=globals_dict;B={}if D is None else dict(D);B.setdefault('run_script',A.run);E=True
		if E:A._download_bundle()
		A._loader.ensure_loaded();B.setdefault('scripts',A._loader._scripts);C=A._resolve_bundle_name(script_name);print(f"[ScriptRunner] Priority 2 — bundle: {C!r}");B.setdefault('__file__',C);A._loader.run_script(C,B)
	def _resolve_bundle_name(A,script_name):
		B=script_name
		for C in A._bundle_candidates(B):
			if A._loader.has_script(C):return C
		raise KeyError(f"[ScriptRunner] {B!r} not found in bundle. Tried: {A._bundle_candidates(B)}")
	@staticmethod
	def _bundle_candidates(script_name):A=script_name;B=_base_name(A);return[A,B+'.py.min',B+'.py']
	def _bundle_needs_update(A):
		if not os.path.isfile(A._bundle_path):print('[ScriptRunner] Bundle absent — will download.');return True
		if not A._bundle_url:return False
		try:
			import requests as E;D=E.head(A._bundle_url,timeout=10);D.raise_for_status();B=D.headers.get('ETag','');C=''
			if os.path.isfile(A._etag_path):
				with open(A._etag_path,'r',encoding='utf-8')as F:C=F.read().strip()
			if B and B!=C:print(f"[ScriptRunner] Bundle ETag changed ({C!r} → {B!r}) — will re-download.");return True
			print('[ScriptRunner] Bundle is up to date (ETag match).');return False
		except Exception as G:print(f"[ScriptRunner] ETag check failed ({G}) — using cached bundle.");return False
	def _download_bundle(A):
		import requests as E;print(f"[ScriptRunner] Downloading bundle from {A._bundle_url!r} → {A._bundle_path!r} …");B=E.get(A._bundle_url,timeout=30);B.raise_for_status()
		with open(A._bundle_path,'wb')as C:C.write(B.content)
		D=B.headers.get('ETag','')
		if D:
			with open(A._etag_path,'w',encoding='utf-8')as C:C.write(D)
		A._loader._loaded=False;A._loader._scripts.clear();print('[ScriptRunner] Bundle downloaded successfully.')
def _base_name(script_name):
	A=script_name
	for B in('.min','.py'):
		if A.endswith(B):A=A[:-len(B)]
	return A