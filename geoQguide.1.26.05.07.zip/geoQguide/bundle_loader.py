import sys,tarfile,io,time,ctypes,builtins,traceback
from cryptography.fernet import Fernet
PROTECT_BLOCK_DECOMPILERS=True
PROTECT_CLEVEL_COMPILE=True
PROTECT_CLEVEL_EXEC=True
PROTECT_TRUSTED_EXEC=True
_DISASM_MODULES=frozenset({'decompile3','uncompyle6','decompile'})
_PY_FILE_INPUT=257
def _security_alert(reason,detail=''):caller=traceback.extract_stack()[-2];print(f"[BundleLoader][SECURITY] {reason}"+(f" | {detail}"if detail else'')+f" | from {caller.filename}:{caller.lineno}")
if PROTECT_BLOCK_DECOMPILERS:
	def _audit_guard(event,args):
		if event=='import'and args and args[0]in _DISASM_MODULES:_security_alert('disassembler import blocked',f"module={args[0]!r}");raise RuntimeError(f"[BundleLoader] Blocked import of disassembler: {args[0]!r}")
	sys.addaudithook(_audit_guard)
def _get_pylib():
	if sys.platform=='win32':name=f"python{sys.version_info.major}{sys.version_info.minor}.dll";return ctypes.PyDLL(name)
	if sys.platform=='darwin':from ctypes.util import find_library;name=find_library(f"python{sys.version_info.major}.{sys.version_info.minor}");return ctypes.PyDLL(name)
	return ctypes.PyDLL(None)
_pylib=_get_pylib()
del _get_pylib
if PROTECT_CLEVEL_COMPILE:
	_Py_CompileString=_pylib.Py_CompileString;_Py_CompileString.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];_Py_CompileString.restype=ctypes.py_object
	def _compile(source,filename):return _Py_CompileString(source.encode('utf-8'),filename.encode('utf-8'),_PY_FILE_INPUT)
else:
	def _compile(source,filename):return builtins.compile(source,filename,'exec')
if PROTECT_CLEVEL_EXEC:
	_PyEval_EvalCode=_pylib.PyEval_EvalCode;_PyEval_EvalCode.argtypes=[ctypes.py_object,ctypes.py_object,ctypes.py_object];_PyEval_EvalCode.restype=ctypes.py_object
	def _eval_code(code,globs):_PyEval_EvalCode(code,globs,globs)
else:
	def _eval_code(code,globs):exec(code,globs)
_trusted_codes=set()
if PROTECT_TRUSTED_EXEC and PROTECT_CLEVEL_EXEC:
	def _safe_exec(code,globals_=None,locals_=None):
		if code not in _trusted_codes:_security_alert('untrusted exec() attempt',f"code_obj={code!r}");raise RuntimeError('[BundleLoader] exec() called with untrusted code object')
		g={}if globals_ is None else globals_
		if'__builtins__'not in g:g['__builtins__']=_safe_builtins
		_eval_code(code,g)
	_safe_builtins={**vars(builtins),'exec':_safe_exec}
else:_safe_builtins=dict(vars(builtins))
import types as _types
if PROTECT_CLEVEL_EXEC and not isinstance(builtins.exec,_types.BuiltinFunctionType):_security_alert('builtins.exec is monkey-patched',f"type={type(builtins.exec)!r}")
if PROTECT_CLEVEL_COMPILE and not isinstance(builtins.compile,_types.BuiltinFunctionType):_security_alert('builtins.compile is monkey-patched',f"type={type(builtins.compile)!r}")
del _types
class BundleLoader:
	def __init__(self,bundle_path,key):self._bundle_path=bundle_path;self._fernet=Fernet(key);self._scripts={};self._loaded=False
	def ensure_loaded(self):
		if not self._loaded:self._load()
	def has_script(self,name):self.ensure_loaded();return name in self._scripts
	def run_script(self,name,globals_dict=None):
		self.ensure_loaded()
		if name not in self._scripts:raise KeyError(f"[BundleLoader] Script not found in bundle: {name!r}")
		g={}if globals_dict is None else dict(globals_dict);g.setdefault('scripts',self._scripts);g['__builtins__']=_safe_builtins;_eval_code(self._scripts[name],g)
	def _load(self):
		t0=time.perf_counter()
		with open(self._bundle_path,'rb')as fh:encrypted=fh.read()
		t1=time.perf_counter();print(f"[BundleLoader] Read:               {(t1-t0)*1000:.1f} ms  ({len(encrypted):,} bytes)");decrypted=self._fernet.decrypt(encrypted);t2=time.perf_counter();print(f"[BundleLoader] Decrypt:            {(t2-t1)*1000:.1f} ms  ({len(decrypted):,} bytes)")
		with tarfile.open(fileobj=io.BytesIO(decrypted),mode='r:gz')as tar:
			for member in tar.getmembers():source=tar.extractfile(member).read().decode('utf-8');code=_compile(source,member.name);del source;self._scripts[member.name]=code;_trusted_codes.add(code)
		del decrypted;t3=time.perf_counter();names=', '.join(self._scripts);print(f"[BundleLoader] Decompress+compile: {(t3-t2)*1000:.1f} ms  ({len(self._scripts)} scripts: {names})");print(f"[BundleLoader] Total load time:    {(t3-t0)*1000:.1f} ms");self._loaded=True