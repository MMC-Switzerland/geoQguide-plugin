import os
from.settings_manager import SettingsManager
_HERE=os.path.dirname(os.path.abspath(__file__))
class GeoQguidePlugin:
	def __init__(A,iface):A.iface=iface;A._action=None;A._runner=None;A._api_client=None;A.settings=SettingsManager();A.settings.write_defaults()
	def initGui(A):from qgis.PyQt.QtWidgets import QAction as C;A._action=C('geoQguide',A.iface.mainWindow());A._action.triggered.connect(A.run);A.iface.addPluginToMenu('geoQguide',A._action);from.version_check import schedule_check as D;import configparser as E,os;B=E.ConfigParser();B.read(os.path.join(_HERE,'metadata.txt'));F=B.get('general','version',fallback='0');D(F,A.iface)
	def unload(A):A.iface.removePluginMenu('geoQguide',A._action);A._action=None;A._runner=None
	def _get_runner(A):
		if A._runner is None:from.runner import ScriptRunner as B;A._runner=B(bundle_path=os.path.join(_HERE,'bundle.tar.gz.enc'),api_client=A._get_api_client())
		return A._runner
	def _get_api_client(A):
		if A._api_client is None:
			try:from.api_client import GeoQGuideApiClient as B;C=A.settings.read();A._api_client=B(base_url=C.api_base_url)
			except Exception as D:print(f"[geoQguide] Could not initialise API client: {D}")
		return A._api_client
	def run(A):from.launcher_dialog import launch as B;B(runner=A._get_runner(),settings_manager=A.settings,api_client=A._get_api_client())