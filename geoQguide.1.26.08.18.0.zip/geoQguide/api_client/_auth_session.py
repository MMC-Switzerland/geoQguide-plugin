from __future__ import annotations

from typing import TYPE_CHECKING

from .geo_q_guide_api_client.api.auth import login as login_api
from .geo_q_guide_api_client.api.auth import logout as logout_api
from .geo_q_guide_api_client.api.auth import refresh_token as refresh_api
from .geo_q_guide_api_client.client import AuthenticatedClient, Client
from .geo_q_guide_api_client.models.auth_error_code import AuthErrorCode
from .geo_q_guide_api_client.models.auth_error_response import AuthErrorResponse
from .geo_q_guide_api_client.models.login_request import LoginRequest
from .geo_q_guide_api_client.models.login_response import LoginResponse
from .geo_q_guide_api_client.models.logout_request import LogoutRequest
from .geo_q_guide_api_client.models.refresh_request import RefreshRequest
from .geo_q_guide_api_client.models.refresh_response import RefreshResponse
from .exceptions import AuthError, DeviceSwitchCooldown, DeviceSwitchRequired, SessionExpiredError
from ._device_fingerprint import get_hostname
from .geo_q_guide_api_client.types import Unset

if TYPE_CHECKING:
    from ._token_store import TokenStore


# The wire format of errorCode changed from a number to the enum name. Servers
# and plugins are deployed independently, so any combination of the two can meet
# and BOTH forms must stay readable:
#   * an older server sends 1
#   * a newer server sends "InvalidCredentials"
# The numbers come from the server-side AuthErrorCode enum and are frozen: they
# only describe what old builds put on the wire.
_LEGACY_ERROR_CODE_NAMES = {
    0: "InvalidCode",
    1: "InvalidCredentials",
    2: "DeviceSwitchRequired",
    3: "DeviceSwitchCooldown",
    4: "RefreshTokenInvalid",
    5: "RefreshTokenExpired",
    6: "FingerprintMismatch",
    7: "AccessTokenMissing",
    8: "AccessTokenInvalid",
    9: "AccessTokenExpired",
}


def _install_auth_error_code_compat() -> None:
    """Teach the generated AuthErrorCode to accept every form of a code.

    The generated model calls ``AuthErrorCode(value)`` directly, so an
    unexpected form raises ValueError deep inside parsing and the caller never
    sees the response at all. Enum's ``_missing_`` hook is the supported way to
    widen that lookup, and installing it from HERE (rather than editing the
    generated file) means it survives the next client regeneration.
    """
    if getattr(AuthErrorCode, "_gqg_compat_installed", False):
        return

    @classmethod  # type: ignore[misc]
    def _missing_(cls, value):  # noqa: ANN001, ANN206
        # bool is an int subclass; it is never a valid code.
        if isinstance(value, bool):
            return None

        if isinstance(value, int):
            value = _LEGACY_ERROR_CODE_NAMES.get(value)

        if isinstance(value, str):
            # Case-insensitive so a casing change on the server is not an outage.
            folded = value.casefold()
            for member in cls:
                if member.value.casefold() == folded:
                    return member

        return None

    AuthErrorCode._missing_ = _missing_
    AuthErrorCode._gqg_compat_installed = True


_install_auth_error_code_compat()


def _auth_error_code(parsed) -> AuthErrorCode | None:
    """Return the error code of an AuthErrorResponse, whichever field carries it.

    Newer servers add the name under ``error`` and keep the legacy number in
    ``errorCode``; older ones only have the latter. Returns None when the code
    cannot be recognised, which callers must treat as "some auth failure" rather
    than assuming any particular cause.
    """
    for value in (getattr(parsed, "error", None), getattr(parsed, "error_code", None)):
        if value is None or isinstance(value, Unset):
            continue
        try:
            return AuthErrorCode(value)
        except ValueError:
            continue

    return None


# Shown when the server reports a code this build has never heard of. Updating
# the plugin is the only real fix, so the message says so.
_UNKNOWN_CODE_HINT = (
    "the server reported an error this plugin version does not understand. "
    "Please update the geoQguide plugin."
)


def _log(message: str) -> None:
    """Log auth events to the standard QGIS log (falls back to print outside QGIS).

    Uses the shared "geoQguide" tab; the "[auth]" prefix identifies the source.
    """
    try:
        from qgis.core import Qgis, QgsMessageLog  # noqa: PLC0415 — lazy, QGIS-only
        QgsMessageLog.logMessage(f"[auth] {message}", "geoQguide", Qgis.Warning)
    except Exception:
        print(f"[auth] {message}")


class AuthSession:
    """Calls /auth/* endpoints and keeps TokenStore up to date."""

    def __init__(self, base_url: str, device_fingerprint: str, store: TokenStore, verify_ssl: bool = True) -> None:
        self._base_url = base_url
        self._device_fingerprint = device_fingerprint
        self._store = store
        self._anon_client = Client(base_url=base_url, verify_ssl=verify_ssl)
        self._verify_ssl = verify_ssl

    def login(self, email: str, password: str, confirm_device_switch: bool = False) -> None:
        body = LoginRequest(
            email=email,
            password=password,
            device_fingerprint=self._device_fingerprint,
            machine_name=get_hostname(),
            confirm_device_switch=confirm_device_switch,
        )
        try:
            resp = login_api.sync_detailed(client=self._anon_client, body=body)
        except ValueError as e:
            # Raised while parsing an error code the generated model rejects.
            _log(f"Login failed: unreadable error code from the server ({e!r}).")
            raise AuthError(f"Login failed: {_UNKNOWN_CODE_HINT}") from e

        if isinstance(resp.parsed, AuthErrorResponse):
            code = _auth_error_code(resp.parsed)
            if code == AuthErrorCode.INVALIDCREDENTIALS:
                raise AuthError("Invalid email or password")
            if code == AuthErrorCode.DEVICESWITCHREQUIRED:
                raise DeviceSwitchRequired(
                    "Login from a new device requires confirmation. "
                    "Re-call login() with confirm_device_switch=True."
                )
            if code == AuthErrorCode.DEVICESWITCHCOOLDOWN:
                raise DeviceSwitchCooldown("Device switch not allowed — 30-day cooldown has not elapsed.")
            if code is None:
                raise AuthError(f"Login failed: {_UNKNOWN_CODE_HINT}")
            raise AuthError(f"Login failed (error code {code}).")

        if not isinstance(resp.parsed, LoginResponse) or not resp.parsed.access_token or not resp.parsed.refresh_token:
            raise AuthError(f"Login failed: unexpected response (HTTP {resp.status_code}).")

        self._store.set_tokens(resp.parsed.access_token, resp.parsed.refresh_token)

    def refresh(self) -> None:
        refresh_token = self._store.refresh_token
        if not refresh_token:
            _log("Logged off: no refresh token in the store (never logged in, auth DB unavailable, or cleared).")
            raise SessionExpiredError("No refresh token stored. Please log in.")

        body = RefreshRequest(
            refresh_token=refresh_token,
            device_fingerprint=self._device_fingerprint,
        )
        try:
            resp = refresh_api.sync_detailed(client=self._anon_client, body=body)
        except ValueError as e:
            # An unreadable code is NOT a verdict on the refresh token, so the
            # tokens are kept: a later call can still succeed.
            _log(f"Token refresh failed: unreadable error code from the server ({e!r}); keeping stored tokens.")
            raise AuthError(f"Token refresh failed: {_UNKNOWN_CODE_HINT}") from e

        if isinstance(resp.parsed, AuthErrorResponse):
            code = _auth_error_code(resp.parsed)
            if code in (
                AuthErrorCode.REFRESHTOKENINVALID,
                AuthErrorCode.REFRESHTOKENEXPIRED,
                AuthErrorCode.FINGERPRINTMISMATCH,
            ):
                # Definitive auth rejection — the refresh token is unusable; clear it.
                self._store.clear()
                _log(
                    f"Logged off: server rejected token refresh with {code!r} "
                    f"(fingerprint prefix: {self._device_fingerprint.split(':', 1)[0]}:)."
                )
                raise SessionExpiredError("Session expired. Please log in again.")
            # Other auth error codes are not refresh-token verdicts — keep tokens
            # so a later retry can succeed.
            _log(f"Token refresh failed (error code {code!r}); keeping stored tokens for retry.")
            raise AuthError(f"Token refresh failed (error code {code}).")

        if not isinstance(resp.parsed, RefreshResponse) or not resp.parsed.access_token:
            # Transient/infrastructure problem (5xx, proxy, malformed body) — NOT an
            # auth verdict. Keep the tokens; the next call will retry the refresh.
            _log(
                f"Token refresh failed: unexpected response (HTTP {resp.status_code}); "
                "keeping stored tokens for retry."
            )
            raise AuthError(f"Token refresh failed: unexpected response (HTTP {resp.status_code}). Please try again.")

        # Refresh token may not rotate (server keeps it for 60 days); keep existing if not returned.
        new_refresh = resp.parsed.refresh_token or refresh_token
        self._store.set_tokens(resp.parsed.access_token, new_refresh)

    def logout(self) -> None:
        refresh_token = self._store.refresh_token
        if not refresh_token:
            return  # Already logged out locally

        try:
            if not self._store.is_access_token_fresh():
                self.refresh()
            auth_client = AuthenticatedClient(
                base_url=self._base_url,
                token=self._store.access_token,
                verify_ssl=self._verify_ssl,
            )
            logout_api.sync_detailed(
                client=auth_client,
                body=LogoutRequest(refresh_token=refresh_token),
            )
        except Exception as e:
            _log(f"Logout: server-side revocation failed ({e!r}); clearing local tokens anyway.")
        finally:
            _log("Logged off: user-initiated logout — local tokens cleared.")
            self._store.clear()
