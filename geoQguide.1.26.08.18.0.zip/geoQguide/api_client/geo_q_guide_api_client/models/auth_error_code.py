from enum import Enum


class AuthErrorCode(str, Enum):
    ACCESSTOKENEXPIRED = "AccessTokenExpired"
    ACCESSTOKENINVALID = "AccessTokenInvalid"
    ACCESSTOKENMISSING = "AccessTokenMissing"
    DEVICESWITCHCOOLDOWN = "DeviceSwitchCooldown"
    DEVICESWITCHREQUIRED = "DeviceSwitchRequired"
    FINGERPRINTMISMATCH = "FingerprintMismatch"
    INVALIDCODE = "InvalidCode"
    INVALIDCREDENTIALS = "InvalidCredentials"
    REFRESHTOKENEXPIRED = "RefreshTokenExpired"
    REFRESHTOKENINVALID = "RefreshTokenInvalid"

    def __str__(self) -> str:
        return str(self.value)
