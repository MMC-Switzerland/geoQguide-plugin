from collections.abc import Mapping
from io import BytesIO
from typing import Any, TypeVar

from attrs import define as _attrs_define

from .. import types
from ..types import File

T = TypeVar("T", bound="CreateOrUpdateLegendBody")


@_attrs_define
class CreateOrUpdateLegendBody:
    """
    Attributes:
        data_source_uri (str): The QGIS data source URI of the layer Example: contextualWMSLegend=0&crs=EPSG:32632&dpiMo
            de=7&featureCount=10&format=image/png&layers=ulter_cont_unesco&styles&tilePixelRatio=0&url=http://www502.regione
            .toscana.it/wmsraster/com.rt.wms.RTmap/wms?map%3Dwmspiapae%26map_resolution%3D91.
        items (str): JSON array with the metadata of every legend item, in the same order as the uploaded images. Each
            element supports name (string, required), description (string, required), isBackground (boolean, optional,
            defaults to false) and itemClass (string, optional, one of NoAction, ReferenceOnly, RiskOrCost, NotUsable,
            defaults to NoAction). Example: [{"name":"Forest","description":"Dense forest
            cover","isBackground":false,"itemClass":"RiskOrCost"},{"name":"Water","description":"Open water
            bodies","isBackground":true,"itemClass":"NoAction"}].
        images (list[File]): Image files of the legend items. Provide one file per element of the 'items' array, in the
            same order.
    """

    data_source_uri: str
    items: str
    images: list[File]

    def to_dict(self) -> dict[str, Any]:
        data_source_uri = self.data_source_uri

        items = self.items

        images = []
        for images_item_data in self.images:
            images_item = images_item_data.to_tuple()

            images.append(images_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "dataSourceUri": data_source_uri,
                "items": items,
                "images": images,
            }
        )

        return field_dict

    def to_multipart(self) -> types.RequestFiles:
        files: types.RequestFiles = []

        files.append(("dataSourceUri", (None, str(self.data_source_uri).encode(), "text/plain")))

        files.append(("items", (None, str(self.items).encode(), "text/plain")))

        for images_item_element in self.images:
            files.append(("images", images_item_element.to_tuple()))

        return files

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        data_source_uri = d.pop("dataSourceUri")

        items = d.pop("items")

        images = []
        _images = d.pop("images")
        for images_item_data in _images:
            images_item = File(payload=BytesIO(images_item_data))

            images.append(images_item)

        create_or_update_legend_body = cls(
            data_source_uri=data_source_uri,
            items=items,
            images=images,
        )

        return create_or_update_legend_body
