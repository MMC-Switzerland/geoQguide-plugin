from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..models.auth_error_code import AuthErrorCode
from ..types import UNSET, Unset

T = TypeVar("T", bound="AuthErrorResponse")


@_attrs_define
class AuthErrorResponse:
    """
    Attributes:
        error_code (Union[Unset, int]):
        error (Union[Unset, AuthErrorCode]):
        message (Union[None, Unset, str]):
    """

    error_code: Union[Unset, int] = UNSET
    error: Union[Unset, AuthErrorCode] = UNSET
    message: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        error_code = self.error_code

        error: Union[Unset, str] = UNSET
        if not isinstance(self.error, Unset):
            error = self.error.value

        message: Union[None, Unset, str]
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if error_code is not UNSET:
            field_dict["errorCode"] = error_code
        if error is not UNSET:
            field_dict["error"] = error
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        error_code = d.pop("errorCode", UNSET)

        _error = d.pop("error", UNSET)
        error: Union[Unset, AuthErrorCode]
        if isinstance(_error, Unset):
            error = UNSET
        else:
            error = AuthErrorCode(_error)

        def _parse_message(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        message = _parse_message(d.pop("message", UNSET))

        auth_error_response = cls(
            error_code=error_code,
            error=error,
            message=message,
        )

        return auth_error_response
