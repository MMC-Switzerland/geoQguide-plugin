from enum import Enum


class LegendItemClass(str, Enum):
    NOACTION = "NoAction"
    NOTUSABLE = "NotUsable"
    REFERENCEONLY = "ReferenceOnly"
    RISKORCOST = "RiskOrCost"

    def __str__(self) -> str:
        return str(self.value)
