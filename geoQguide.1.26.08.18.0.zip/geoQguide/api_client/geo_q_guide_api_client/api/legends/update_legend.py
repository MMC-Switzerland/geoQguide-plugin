from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.legend_model import LegendModel
from ...models.update_legend_body import UpdateLegendBody
from ...types import Response


def _get_kwargs(
    *,
    body: UpdateLegendBody,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/legend/update",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, LegendModel]]:
    if response.status_code == 200:
        response_200 = LegendModel.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, LegendModel]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateLegendBody,
) -> Response[Union[Any, LegendModel]]:
    """Update legend with new items and images

     Updates an existing legend identified by dataSourceUri. Replaces all existing items with new ones.
    Send the item metadata as a JSON array in the 'items' field and the matching image files as repeated
    'images' file fields, in the same order. Each item requires name and description, and optionally
    isBackground and itemClass. At least one item must be marked as background.

    Args:
        body (UpdateLegendBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, LegendModel]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateLegendBody,
) -> Optional[Union[Any, LegendModel]]:
    """Update legend with new items and images

     Updates an existing legend identified by dataSourceUri. Replaces all existing items with new ones.
    Send the item metadata as a JSON array in the 'items' field and the matching image files as repeated
    'images' file fields, in the same order. Each item requires name and description, and optionally
    isBackground and itemClass. At least one item must be marked as background.

    Args:
        body (UpdateLegendBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, LegendModel]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateLegendBody,
) -> Response[Union[Any, LegendModel]]:
    """Update legend with new items and images

     Updates an existing legend identified by dataSourceUri. Replaces all existing items with new ones.
    Send the item metadata as a JSON array in the 'items' field and the matching image files as repeated
    'images' file fields, in the same order. Each item requires name and description, and optionally
    isBackground and itemClass. At least one item must be marked as background.

    Args:
        body (UpdateLegendBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, LegendModel]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: UpdateLegendBody,
) -> Optional[Union[Any, LegendModel]]:
    """Update legend with new items and images

     Updates an existing legend identified by dataSourceUri. Replaces all existing items with new ones.
    Send the item metadata as a JSON array in the 'items' field and the matching image files as repeated
    'images' file fields, in the same order. Each item requires name and description, and optionally
    isBackground and itemClass. At least one item must be marked as background.

    Args:
        body (UpdateLegendBody):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, LegendModel]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
