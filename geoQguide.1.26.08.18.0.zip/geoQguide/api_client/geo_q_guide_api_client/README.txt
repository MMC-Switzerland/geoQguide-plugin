AUTO-GENERATED - DO NOT EDIT

This folder is produced by openapi-python-client from swagger.json.
It is wiped and recreated every time regen_client.bat is run.

To regenerate: run plugin-root\api_client\regen_client.bat

Any changes made here will be lost on the next regeneration.
Put custom code in plugin-root\api_client\client.py instead.

The API sends enums as strings, so no post-generation patching is
needed any more. NOTE the generator builds member names by upper-casing
the value and REMOVING separators, so "InvalidCredentials" becomes
AuthErrorCode.INVALIDCREDENTIALS - not INVALID_CREDENTIALS. Check the
generated enum before referring to a member.
