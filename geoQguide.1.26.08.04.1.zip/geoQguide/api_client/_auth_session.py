from __future__ import annotations

from typing import TYPE_CHECKING

from .geo_q_guide_api_client.api.auth import login as login_api
from .geo_q_guide_api_client.api.auth import logout as logout_api
from .geo_q_guide_api_client.api.auth import refresh_token as refresh_api
from .geo_q_guide_api_client.client import AuthenticatedClient, Client
from .geo_q_guide_api_client.models.auth_error_code import AuthErrorCode
from .geo_q_guide_api_client.models.auth_error_response import AuthErrorResponse
from .geo_q_guide_api_client.models.login_request import LoginRequest
from .geo_q_guide_api_client.models.login_response import LoginResponse
from .geo_q_guide_api_client.models.logout_request import LogoutRequest
from .geo_q_guide_api_client.models.refresh_request import RefreshRequest
from .geo_q_guide_api_client.models.refresh_response import RefreshResponse
from .exceptions import AuthError, DeviceSwitchCooldown, DeviceSwitchRequired, SessionExpiredError
from ._device_fingerprint import get_hostname

if TYPE_CHECKING:
    from ._token_store import TokenStore


def _log(message: str) -> None:
    """Log auth events to the standard QGIS log (falls back to print outside QGIS).

    Uses the shared "geoQguide" tab; the "[auth]" prefix identifies the source.
    """
    try:
        from qgis.core import Qgis, QgsMessageLog  # noqa: PLC0415 — lazy, QGIS-only
        QgsMessageLog.logMessage(f"[auth] {message}", "geoQguide", Qgis.Warning)
    except Exception:
        print(f"[auth] {message}")


class AuthSession:
    """Calls /auth/* endpoints and keeps TokenStore up to date."""

    def __init__(self, base_url: str, device_fingerprint: str, store: TokenStore, verify_ssl: bool = True) -> None:
        self._base_url = base_url
        self._device_fingerprint = device_fingerprint
        self._store = store
        self._anon_client = Client(base_url=base_url, verify_ssl=verify_ssl)
        self._verify_ssl = verify_ssl

    def login(self, email: str, password: str, confirm_device_switch: bool = False) -> None:
        body = LoginRequest(
            email=email,
            password=password,
            device_fingerprint=self._device_fingerprint,
            machine_name=get_hostname(),
            confirm_device_switch=confirm_device_switch,
        )
        resp = login_api.sync_detailed(client=self._anon_client, body=body)

        if isinstance(resp.parsed, AuthErrorResponse):
            code = resp.parsed.error_code
            if code == AuthErrorCode.INVALID_CREDENTIALS:
                raise AuthError("Invalid email or password")
            if code == AuthErrorCode.DEVICE_SWITCH_REQUIRED:
                raise DeviceSwitchRequired(
                    "Login from a new device requires confirmation. "
                    "Re-call login() with confirm_device_switch=True."
                )
            if code == AuthErrorCode.DEVICE_SWITCH_COOLDOWN:
                raise DeviceSwitchCooldown("Device switch not allowed — 30-day cooldown has not elapsed.")
            raise AuthError(f"Login failed (error code {code}).")

        if not isinstance(resp.parsed, LoginResponse) or not resp.parsed.access_token or not resp.parsed.refresh_token:
            raise AuthError(f"Login failed: unexpected response (HTTP {resp.status_code}).")

        self._store.set_tokens(resp.parsed.access_token, resp.parsed.refresh_token)

    def refresh(self) -> None:
        refresh_token = self._store.refresh_token
        if not refresh_token:
            _log("Logged off: no refresh token in the store (never logged in, auth DB unavailable, or cleared).")
            raise SessionExpiredError("No refresh token stored. Please log in.")

        body = RefreshRequest(
            refresh_token=refresh_token,
            device_fingerprint=self._device_fingerprint,
        )
        resp = refresh_api.sync_detailed(client=self._anon_client, body=body)

        if isinstance(resp.parsed, AuthErrorResponse):
            code = resp.parsed.error_code
            if code in (
                AuthErrorCode.REFRESH_TOKEN_INVALID,
                AuthErrorCode.REFRESH_TOKEN_EXPIRED,
                AuthErrorCode.FINGERPRINT_MISMATCH,
            ):
                # Definitive auth rejection — the refresh token is unusable; clear it.
                self._store.clear()
                _log(
                    f"Logged off: server rejected token refresh with {code!r} "
                    f"(fingerprint prefix: {self._device_fingerprint.split(':', 1)[0]}:)."
                )
                raise SessionExpiredError("Session expired. Please log in again.")
            # Other auth error codes are not refresh-token verdicts — keep tokens
            # so a later retry can succeed.
            _log(f"Token refresh failed (error code {code!r}); keeping stored tokens for retry.")
            raise AuthError(f"Token refresh failed (error code {code}).")

        if not isinstance(resp.parsed, RefreshResponse) or not resp.parsed.access_token:
            # Transient/infrastructure problem (5xx, proxy, malformed body) — NOT an
            # auth verdict. Keep the tokens; the next call will retry the refresh.
            _log(
                f"Token refresh failed: unexpected response (HTTP {resp.status_code}); "
                "keeping stored tokens for retry."
            )
            raise AuthError(f"Token refresh failed: unexpected response (HTTP {resp.status_code}). Please try again.")

        # Refresh token may not rotate (server keeps it for 60 days); keep existing if not returned.
        new_refresh = resp.parsed.refresh_token or refresh_token
        self._store.set_tokens(resp.parsed.access_token, new_refresh)

    def logout(self) -> None:
        refresh_token = self._store.refresh_token
        if not refresh_token:
            return  # Already logged out locally

        try:
            if not self._store.is_access_token_fresh():
                self.refresh()
            auth_client = AuthenticatedClient(
                base_url=self._base_url,
                token=self._store.access_token,
                verify_ssl=self._verify_ssl,
            )
            logout_api.sync_detailed(
                client=auth_client,
                body=LogoutRequest(refresh_token=refresh_token),
            )
        except Exception as e:
            _log(f"Logout: server-side revocation failed ({e!r}); clearing local tokens anyway.")
        finally:
            _log("Logged off: user-initiated logout — local tokens cleared.")
            self._store.clear()
