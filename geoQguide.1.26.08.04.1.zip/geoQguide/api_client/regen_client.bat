@echo off
setlocal
cd /d "%~dp0"

echo Downloading swagger.json...
curl -k https://localhost:7294/swagger/v1/swagger.json -o swagger.json
if %ERRORLEVEL% neq 0 (
    powershell -Command "Write-Host 'ERROR: Failed to download swagger.json' -ForegroundColor Red"
    goto :end
)

echo Generating client...
openapi-python-client generate --path swagger.json --overwrite
if %ERRORLEVEL% neq 0 (
    powershell -Command "Write-Host 'ERROR: openapi-python-client failed' -ForegroundColor Red"
    goto :end
)

echo Updating geo_q_guide_api_client...
if exist "geo_q_guide_api_client" (
    rmdir /s /q "geo_q_guide_api_client"
)
move "geo-q-guide-api-client\geo_q_guide_api_client" "geo_q_guide_api_client"
rmdir /s /q "geo-q-guide-api-client"

echo Applying post-generation patches...
py _regen_patch.py
if %ERRORLEVEL% neq 0 (
    powershell -Command "Write-Host 'ERROR: _regen_patch.py failed - generated client left unpatched' -ForegroundColor Red"
    goto :end
)

echo Writing README...
(
    echo AUTO-GENERATED — DO NOT EDIT
    echo.
    echo This folder is produced by openapi-python-client from swagger.json.
    echo It is wiped and recreated every time regen_client.bat is run.
    echo.
    echo To regenerate: run plugin-root\api_client\regen_client.bat
    echo.
    echo Any changes made here will be lost on the next regeneration.
    echo Put custom code in plugin-root\api_client\client.py instead.
    echo.
    echo Exception: models\auth_error_code.py is rewritten with named enum
    echo members by api_client\_regen_patch.py on every regeneration.
) > "geo_q_guide_api_client\README.txt"

powershell -Command "Write-Host 'Done. Client regenerated successfully.' -ForegroundColor Green"

:end
echo.
pause
