AUTO-GENERATED — DO NOT EDIT

This folder is produced by openapi-python-client from swagger.json.
It is wiped and recreated every time regen_client.bat is run.

To regenerate: run plugin-root\api_client\regen_client.bat

Any changes made here will be lost on the next regeneration.
Put custom code in plugin-root\api_client\client.py instead.

Exception: models\auth_error_code.py is rewritten with named enum
members by api_client\_regen_patch.py on every regeneration.
