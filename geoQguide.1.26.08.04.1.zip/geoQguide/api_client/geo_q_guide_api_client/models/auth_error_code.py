from enum import IntEnum


class AuthErrorCode(IntEnum):
    """Mirrors the server-side AuthErrorCode enum.

    NOTE: the generator emits VALUE_0..VALUE_9; regen_client.bat re-applies
    these names automatically via api_client/_regen_patch.py.
    """

    # Invalid sentinel — this value should never be used.
    INVALID_CODE = 0

    # ── Login errors ──────────────────────────────────────────────
    # Email or password is incorrect.
    INVALID_CREDENTIALS = 1
    # Login from a new device fingerprint requires explicit user confirmation.
    # Client should re-submit with confirm_device_switch=True.
    DEVICE_SWITCH_REQUIRED = 2
    # Device switch not allowed yet — 30-day cooldown has not elapsed.
    DEVICE_SWITCH_COOLDOWN = 3

    # ── Refresh errors ────────────────────────────────────────────
    # Refresh token not found or was already revoked.
    REFRESH_TOKEN_INVALID = 4
    # Refresh token has passed its 60-day expiry.
    REFRESH_TOKEN_EXPIRED = 5
    # Device fingerprint does not match the one stored with this refresh token.
    FINGERPRINT_MISMATCH = 6

    # ── Access token errors (returned by JWT middleware on protected endpoints) ──
    # No Authorization header was provided.
    ACCESS_TOKEN_MISSING = 7
    # The JWT signature is invalid or the token is malformed.
    ACCESS_TOKEN_INVALID = 8
    # The JWT has expired.
    ACCESS_TOKEN_EXPIRED = 9

    def __str__(self) -> str:
        return str(self.value)
