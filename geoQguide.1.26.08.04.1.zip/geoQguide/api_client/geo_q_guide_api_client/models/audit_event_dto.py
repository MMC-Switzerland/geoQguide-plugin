import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.audit_event_status_dto import AuditEventStatusDto
from ..types import UNSET, Unset

T = TypeVar("T", bound="AuditEventDto")


@_attrs_define
class AuditEventDto:
    """
    Attributes:
        event_id (Union[Unset, UUID]):
        occurred_at (Union[Unset, datetime.datetime]):
        session_id (Union[Unset, UUID]):
        run_id (Union[None, UUID, Unset]):
        action (Union[None, Unset, str]):
        status (Union[Unset, AuditEventStatusDto]):
        duration_ms (Union[None, Unset, int]):
        error_message (Union[None, Unset, str]):
        layers_total (Union[None, Unset, int]):
        plugin_version (Union[None, Unset, str]):
        qgis_version (Union[None, Unset, str]):
        os (Union[None, Unset, str]):
        props (Union[Unset, Any]):
    """

    event_id: Union[Unset, UUID] = UNSET
    occurred_at: Union[Unset, datetime.datetime] = UNSET
    session_id: Union[Unset, UUID] = UNSET
    run_id: Union[None, UUID, Unset] = UNSET
    action: Union[None, Unset, str] = UNSET
    status: Union[Unset, AuditEventStatusDto] = UNSET
    duration_ms: Union[None, Unset, int] = UNSET
    error_message: Union[None, Unset, str] = UNSET
    layers_total: Union[None, Unset, int] = UNSET
    plugin_version: Union[None, Unset, str] = UNSET
    qgis_version: Union[None, Unset, str] = UNSET
    os: Union[None, Unset, str] = UNSET
    props: Union[Unset, Any] = UNSET

    def to_dict(self) -> dict[str, Any]:
        event_id: Union[Unset, str] = UNSET
        if not isinstance(self.event_id, Unset):
            event_id = str(self.event_id)

        occurred_at: Union[Unset, str] = UNSET
        if not isinstance(self.occurred_at, Unset):
            occurred_at = self.occurred_at.isoformat()

        session_id: Union[Unset, str] = UNSET
        if not isinstance(self.session_id, Unset):
            session_id = str(self.session_id)

        run_id: Union[None, Unset, str]
        if isinstance(self.run_id, Unset):
            run_id = UNSET
        elif isinstance(self.run_id, UUID):
            run_id = str(self.run_id)
        else:
            run_id = self.run_id

        action: Union[None, Unset, str]
        if isinstance(self.action, Unset):
            action = UNSET
        else:
            action = self.action

        status: Union[Unset, str] = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        duration_ms: Union[None, Unset, int]
        if isinstance(self.duration_ms, Unset):
            duration_ms = UNSET
        else:
            duration_ms = self.duration_ms

        error_message: Union[None, Unset, str]
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        layers_total: Union[None, Unset, int]
        if isinstance(self.layers_total, Unset):
            layers_total = UNSET
        else:
            layers_total = self.layers_total

        plugin_version: Union[None, Unset, str]
        if isinstance(self.plugin_version, Unset):
            plugin_version = UNSET
        else:
            plugin_version = self.plugin_version

        qgis_version: Union[None, Unset, str]
        if isinstance(self.qgis_version, Unset):
            qgis_version = UNSET
        else:
            qgis_version = self.qgis_version

        os: Union[None, Unset, str]
        if isinstance(self.os, Unset):
            os = UNSET
        else:
            os = self.os

        props = self.props

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if event_id is not UNSET:
            field_dict["eventId"] = event_id
        if occurred_at is not UNSET:
            field_dict["occurredAt"] = occurred_at
        if session_id is not UNSET:
            field_dict["sessionId"] = session_id
        if run_id is not UNSET:
            field_dict["runId"] = run_id
        if action is not UNSET:
            field_dict["action"] = action
        if status is not UNSET:
            field_dict["status"] = status
        if duration_ms is not UNSET:
            field_dict["durationMs"] = duration_ms
        if error_message is not UNSET:
            field_dict["errorMessage"] = error_message
        if layers_total is not UNSET:
            field_dict["layersTotal"] = layers_total
        if plugin_version is not UNSET:
            field_dict["pluginVersion"] = plugin_version
        if qgis_version is not UNSET:
            field_dict["qgisVersion"] = qgis_version
        if os is not UNSET:
            field_dict["os"] = os
        if props is not UNSET:
            field_dict["props"] = props

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _event_id = d.pop("eventId", UNSET)
        event_id: Union[Unset, UUID]
        if isinstance(_event_id, Unset):
            event_id = UNSET
        else:
            event_id = UUID(_event_id)

        _occurred_at = d.pop("occurredAt", UNSET)
        occurred_at: Union[Unset, datetime.datetime]
        if isinstance(_occurred_at, Unset):
            occurred_at = UNSET
        else:
            occurred_at = isoparse(_occurred_at)

        _session_id = d.pop("sessionId", UNSET)
        session_id: Union[Unset, UUID]
        if isinstance(_session_id, Unset):
            session_id = UNSET
        else:
            session_id = UUID(_session_id)

        def _parse_run_id(data: object) -> Union[None, UUID, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                run_id_type_0 = UUID(data)

                return run_id_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, UUID, Unset], data)

        run_id = _parse_run_id(d.pop("runId", UNSET))

        def _parse_action(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        action = _parse_action(d.pop("action", UNSET))

        _status = d.pop("status", UNSET)
        status: Union[Unset, AuditEventStatusDto]
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = AuditEventStatusDto(_status)

        def _parse_duration_ms(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        duration_ms = _parse_duration_ms(d.pop("durationMs", UNSET))

        def _parse_error_message(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        error_message = _parse_error_message(d.pop("errorMessage", UNSET))

        def _parse_layers_total(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        layers_total = _parse_layers_total(d.pop("layersTotal", UNSET))

        def _parse_plugin_version(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        plugin_version = _parse_plugin_version(d.pop("pluginVersion", UNSET))

        def _parse_qgis_version(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        qgis_version = _parse_qgis_version(d.pop("qgisVersion", UNSET))

        def _parse_os(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        os = _parse_os(d.pop("os", UNSET))

        props = d.pop("props", UNSET)

        audit_event_dto = cls(
            event_id=event_id,
            occurred_at=occurred_at,
            session_id=session_id,
            run_id=run_id,
            action=action,
            status=status,
            duration_ms=duration_ms,
            error_message=error_message,
            layers_total=layers_total,
            plugin_version=plugin_version,
            qgis_version=qgis_version,
            os=os,
            props=props,
        )

        return audit_event_dto
