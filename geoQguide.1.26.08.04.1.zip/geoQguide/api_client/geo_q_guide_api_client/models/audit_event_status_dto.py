from enum import Enum


class AuditEventStatusDto(str, Enum):
    ABORTED = "aborted"
    ERROR = "error"
    OK = "ok"

    def __str__(self) -> str:
        return str(self.value)
