from http import HTTPStatus
from typing import Any, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.audit_event_dto import AuditEventDto
from ...models.http_validation_problem_details import HttpValidationProblemDetails
from ...types import Response


def _get_kwargs(
    *,
    body: list["AuditEventDto"],
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/audit/events",
    }

    _kwargs["json"] = []
    for body_item_data in body:
        body_item = body_item_data.to_dict()
        _kwargs["json"].append(body_item)

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Optional[Union[Any, HttpValidationProblemDetails]]:
    if response.status_code == 202:
        response_202 = cast(Any, None)
        return response_202

    if response.status_code == 400:
        response_400 = HttpValidationProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = cast(Any, None)
        return response_401

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: Union[AuthenticatedClient, Client], response: httpx.Response
) -> Response[Union[Any, HttpValidationProblemDetails]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: list["AuditEventDto"],
) -> Response[Union[Any, HttpValidationProblemDetails]]:
    """Submit a batch of plugin usage-audit events

     Accepts a JSON array of up to 200 audit events. The endpoint is idempotent: events whose eventId has
    already been stored are silently ignored, so batches may be retried and spilled events replayed
    safely. Always returns 202 for a well-formed body; per-event outcomes are not reported. The user is
    taken from the JWT, so any user identity present in the payload is ignored.

    Args:
        body (list['AuditEventDto']):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, HttpValidationProblemDetails]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: Union[AuthenticatedClient, Client],
    body: list["AuditEventDto"],
) -> Optional[Union[Any, HttpValidationProblemDetails]]:
    """Submit a batch of plugin usage-audit events

     Accepts a JSON array of up to 200 audit events. The endpoint is idempotent: events whose eventId has
    already been stored are silently ignored, so batches may be retried and spilled events replayed
    safely. Always returns 202 for a well-formed body; per-event outcomes are not reported. The user is
    taken from the JWT, so any user identity present in the payload is ignored.

    Args:
        body (list['AuditEventDto']):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, HttpValidationProblemDetails]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: Union[AuthenticatedClient, Client],
    body: list["AuditEventDto"],
) -> Response[Union[Any, HttpValidationProblemDetails]]:
    """Submit a batch of plugin usage-audit events

     Accepts a JSON array of up to 200 audit events. The endpoint is idempotent: events whose eventId has
    already been stored are silently ignored, so batches may be retried and spilled events replayed
    safely. Always returns 202 for a well-formed body; per-event outcomes are not reported. The user is
    taken from the JWT, so any user identity present in the payload is ignored.

    Args:
        body (list['AuditEventDto']):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Union[Any, HttpValidationProblemDetails]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: Union[AuthenticatedClient, Client],
    body: list["AuditEventDto"],
) -> Optional[Union[Any, HttpValidationProblemDetails]]:
    """Submit a batch of plugin usage-audit events

     Accepts a JSON array of up to 200 audit events. The endpoint is idempotent: events whose eventId has
    already been stored are silently ignored, so batches may be retried and spilled events replayed
    safely. Always returns 202 for a well-formed body; per-event outcomes are not reported. The user is
    taken from the JWT, so any user identity present in the payload is ignored.

    Args:
        body (list['AuditEventDto']):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Union[Any, HttpValidationProblemDetails]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
