"""Post-generation patch for the auto-generated API client.

regen_client.bat wipes geo_q_guide_api_client/ on every run, and
openapi-python-client emits integer enums with meaningless member names
(VALUE_0..VALUE_9). This script re-applies the server-side names to
models/auth_error_code.py. regen_client.bat runs it automatically after
every regeneration; it is also safe to run by hand (idempotent).

If the server-side AuthErrorCode enum ever gains/loses values, this script
FAILS loudly — update NAMED_CONTENT below to match the server enum.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ENUM_FILE = Path(__file__).parent / "geo_q_guide_api_client" / "models" / "auth_error_code.py"

# Values the named template below covers — must match the generated enum.
EXPECTED_VALUES = set(range(10))

# Mirror of the server-side AuthErrorCode enum (single source of truth for the names).
NAMED_CONTENT = '''from enum import IntEnum


class AuthErrorCode(IntEnum):
    """Mirrors the server-side AuthErrorCode enum.

    NOTE: the generator emits VALUE_0..VALUE_9; regen_client.bat re-applies
    these names automatically via api_client/_regen_patch.py.
    """

    # Invalid sentinel — this value should never be used.
    INVALID_CODE = 0

    # ── Login errors ──────────────────────────────────────────────
    # Email or password is incorrect.
    INVALID_CREDENTIALS = 1
    # Login from a new device fingerprint requires explicit user confirmation.
    # Client should re-submit with confirm_device_switch=True.
    DEVICE_SWITCH_REQUIRED = 2
    # Device switch not allowed yet — 30-day cooldown has not elapsed.
    DEVICE_SWITCH_COOLDOWN = 3

    # ── Refresh errors ────────────────────────────────────────────
    # Refresh token not found or was already revoked.
    REFRESH_TOKEN_INVALID = 4
    # Refresh token has passed its 60-day expiry.
    REFRESH_TOKEN_EXPIRED = 5
    # Device fingerprint does not match the one stored with this refresh token.
    FINGERPRINT_MISMATCH = 6

    # ── Access token errors (returned by JWT middleware on protected endpoints) ──
    # No Authorization header was provided.
    ACCESS_TOKEN_MISSING = 7
    # The JWT signature is invalid or the token is malformed.
    ACCESS_TOKEN_INVALID = 8
    # The JWT has expired.
    ACCESS_TOKEN_EXPIRED = 9

    def __str__(self) -> str:
        return str(self.value)
'''


def main() -> int:
    if not ENUM_FILE.is_file():
        print(f"ERROR: {ENUM_FILE} not found — run after the client is generated.", file=sys.stderr)
        return 1

    text = ENUM_FILE.read_text(encoding="utf-8")
    values = {int(v) for v in re.findall(r"^    [A-Z_][A-Z_0-9]*\s*=\s*(\d+)\s*$", text, re.M)}
    if values != EXPECTED_VALUES:
        print(
            "ERROR: generated AuthErrorCode enum values changed.\n"
            f"  found   : {sorted(values)}\n"
            f"  expected: {sorted(EXPECTED_VALUES)}\n"
            "The server enum was modified. Update NAMED_CONTENT in _regen_patch.py "
            "to match the server-side AuthErrorCode, then re-run regen_client.bat.",
            file=sys.stderr,
        )
        return 1

    ENUM_FILE.write_text(NAMED_CONTENT, encoding="utf-8")
    print(f"Patched {ENUM_FILE.relative_to(Path(__file__).parent)}: named AuthErrorCode members applied.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
