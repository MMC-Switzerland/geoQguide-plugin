import hashlib
import platform
import uuid

# Two import contexts must work:
#   - QGIS: the plugin is a package -> api_client is a subpackage -> relative.
#   - integration tests: plugin-root is on sys.path, api_client is imported
#     as a TOP-LEVEL package -> no parent to be relative to -> absolute.
try:
    from .._vendor import machineid
except ImportError:
    from _vendor import machineid

# HMAC message for machineid.hashed_id(). Changing this changes every user's
# fingerprint (device-switch flow for the whole fleet) — never edit casually.
_APP_ID = "geoqguide"


def get_hostname() -> str:
    """Machine name for display in device lists (not a fingerprint input).

    platform.node() returns "" when the hostname cannot be determined —
    substitute a placeholder so the server/UI never shows a blank name.
    """
    return platform.node() or "Unknown device"


def get_device_fingerprint(store=None) -> str:
    """Stable device fingerprint for this machine, with algorithm versioning.

    v2 (preferred): OS-install machine ID (Windows MachineGuid, macOS
    IOPlatformUUID, Linux /etc/machine-id — via vendored py-machineid),
    HMAC-SHA256-keyed and hex-encoded, prefixed "2:". Survives hostname
    renames, NIC/dock/MAC changes, OS and QGIS updates; changes only when
    the OS is reinstalled.

    Fallback (prefixed "2f:"): used only when the OS machine ID is
    unavailable (hardened VDI, exotic platforms). Coarse stable traits
    plus a random GUID persisted in the token store — needs no OS probing,
    so it works exactly where the primary path is blocked.

    `store` is the TokenStore/MemoryTokenStore used for GUID persistence;
    without it the fallback degrades to the traits-only hash.
    """
    try:
        return "2:" + machineid.hashed_id(_APP_ID)
    except Exception:
        return _get_fallback_fingerprint(store)


def _persisted_guid(store) -> str:
    """Return the install GUID from the store, creating it on first use.

    Lives in QgsAuthManager next to the tokens and survives logout
    (TokenStore.clear() keeps it). If the auth DB is wiped, the refresh
    token dies with the GUID, so the user re-logins anyway — a fresh
    fingerprint at login is the normal flow, not a mismatch.
    """
    if store is None:
        return ""
    try:
        guid = store.device_guid
        if not guid:
            guid = str(uuid.uuid4())
            store.set_device_guid(guid)
        return guid
    except Exception:
        return ""


def _get_fallback_fingerprint(store) -> str:
    """Last-resort fingerprint when no OS machine ID can be read.

    The persisted GUID supplies per-install uniqueness; the coarse traits are kept only as a
    same-machine sanity anchor if the store is unavailable.
    """
    parts = [
        platform.machine(),     # CPU arch, e.g. AMD64
        platform.processor(),   # CPU brand string (may be empty on Linux)
        _persisted_guid(store),
    ]
    raw = "|".join(parts).encode()
    return "2f:" + hashlib.sha256(raw).hexdigest()
