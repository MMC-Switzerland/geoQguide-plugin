from __future__ import annotations
import json,os,platform,threading,uuid
from datetime import datetime,timezone
FLUSH_SIZE=25
FLUSH_INTERVAL_MS=90000
MAX_SPILL_BYTES=1000000
MAX_EVENTS_PER_RUN=200
MAX_SPILL_AGE_DAYS=7
MAX_ERROR_CHARS=600
MAX_BATCH_SIZE=200
SPILL_FILENAME='geoQguide_audit.jsonl'
_STATUSES='ok','error','aborted'
def _utc_now_iso():return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
def _log(msg):
	try:print(f"[audit] {msg}")
	except Exception:pass
def _spill_dir():
	try:
		from qgis.core import QgsApplication as B;A=B.qgisSettingsDirPath()
		if A and os.path.isdir(A):return A
	except Exception:pass
	import tempfile as C;A=os.path.join(C.gettempdir(),'geoQguide');os.makedirs(A,exist_ok=True);return A
def _plugin_version():
	try:import configparser as B;A=B.ConfigParser();A.read(os.path.join(os.path.dirname(os.path.abspath(__file__)),'metadata.txt'));return A.get('general','version',fallback='')
	except Exception:return''
def _qgis_version():
	try:from qgis.core import Qgis;return str(Qgis.QGIS_VERSION).split('-')[0]
	except Exception:return''
def _os_label():
	try:return f"{platform.system()}-{platform.release()}"
	except Exception:return''
class AuditTransport:
	enabled=False
	def send(A,events):raise NotImplementedError
class NullTransport(AuditTransport):
	enabled=False
	def send(A,events):return False
class ApiAuditTransport(AuditTransport):
	enabled=True
	def __init__(A,api_client):A._api=api_client
	def send(C,events):
		D=events
		if C._api is None or not getattr(C._api,'is_authenticated',False):return False
		from.api_client.geo_q_guide_api_client.api.audit import ingest_audit_events as G;E=True
		for F in range(0,len(D),MAX_BATCH_SIZE):
			H=D[F:F+MAX_BATCH_SIZE];A=[C._to_dto(A)for A in H];A=[A for A in A if A is not None]
			if not A:continue
			I=C._api.call(G.sync_detailed,body=A);B=int(I.status_code)
			if B==202:continue
			if 400<=B<500 and B not in(401,408,429):_log(f"batch rejected (HTTP {B}) — dropping {len(A)} event(s)");continue
			_log(f"send failed (HTTP {B}) — keeping {len(A)} event(s) for retry");E=False;break
		return E
	@staticmethod
	def _to_dto(event):
		A=event
		try:
			from uuid import UUID;from dateutil.parser import isoparse as D;from.api_client.geo_q_guide_api_client.models.audit_event_dto import AuditEventDto as E;from.api_client.geo_q_guide_api_client.models.audit_event_status_dto import AuditEventStatusDto as F;from.api_client.geo_q_guide_api_client.types import UNSET
			def B(value):A=value;return UUID(str(A))if A else None
			C={'event_id':B(A.get('eventId')),'occurred_at':D(A['occurredAt']),'session_id':B(A.get('sessionId')),'run_id':B(A.get('runId')),'action':A.get('action'),'status':F(A.get('status','ok')),'duration_ms':A.get('durationMs'),'error_message':A.get('errorMessage')or None,'layers_total':A.get('layersTotal'),'plugin_version':A.get('pluginVersion'),'qgis_version':A.get('qgisVersion')or None,'os':A.get('os')}
			if A.get('props'):C['props']=A['props']
			else:C['props']=UNSET
			return E(**C)
		except Exception as G:_log(f"skipping malformed event: {G}");return
class AuditLog:
	def __init__(A,settings_manager=None,transport=None):A._settings=settings_manager;A._transport=transport or NullTransport();A._session_id=uuid.uuid4().hex;A._lock=threading.Lock();A._pending=0;A._run_counts={};A._timer=None;A._closed=False;A._spill_path=os.path.join(_spill_dir(),SPILL_FILENAME);A._context={'pluginVersion':_plugin_version(),'qgisVersion':_qgis_version(),'os':_os_label()}
	@property
	def session_id(self):return self._session_id
	@property
	def enabled(self):
		try:
			if self._settings is None:return True
			return bool(self._settings.read().audit_enabled)
		except Exception:return True
	def track(A,action,status='ok',duration_ms=None,layers_total=None,error_message='',run_id='',**I):
		H=layers_total;G=duration_ms;F=status;E=action
		try:
			if A._closed or not A.enabled or not E:return
			B=run_id or''
			if B:
				C=A._run_counts.get(B,0)
				if C>=MAX_EVENTS_PER_RUN:
					if C==MAX_EVENTS_PER_RUN:A._run_counts[B]=C+1;_log(f"run {B}: event cap reached, further events dropped")
					return
				A._run_counts[B]=C+1
			D={'eventId':uuid.uuid4().hex,'occurredAt':_utc_now_iso(),'sessionId':A._session_id,'runId':B or None,'action':str(E),'status':F if F in _STATUSES else'ok','durationMs':int(G)if G is not None else None,'errorMessage':A._trim(error_message)};D.update(A._context)
			if H is not None:D['layersTotal']=int(H)
			if I:D['props']={B:A for(B,A)in I.items()if A is not None}
			A._append(D)
		except Exception as J:_log(f"track failed: {J}")
	def emitter(B,script,run_id):
		def A(action='',**A):A.setdefault('run_id',run_id);B.track(action or script,**A)
		return A
	def set_transport(A,transport):
		try:A._transport=transport;A.flush(reason='transport_ready')
		except Exception as B:_log(f"set_transport failed: {B}")
	def start(A):
		try:A.flush(reason='start');A._arm_timer()
		except Exception as B:_log(f"start failed: {B}")
	def shutdown(A):
		try:A._stop_timer();A.flush(reason='shutdown',blocking=True)
		except Exception as B:_log(f"shutdown failed: {B}")
		finally:A._closed=True
	def flush(A,reason='',blocking=False):
		B=reason
		try:
			A._pending=0
			if not getattr(A._transport,'enabled',False):return
			if blocking:A._send_once(B)
			else:threading.Thread(target=A._send_once,args=(B,),name='geoQguide-audit',daemon=True).start()
		except Exception as C:_log(f"flush failed: {C}")
	@staticmethod
	def _trim(text):
		if not text:return''
		A=str(text).strip().splitlines()[0].strip()
		if len(A)>MAX_ERROR_CHARS:A=A[:MAX_ERROR_CHARS-1].rstrip()+'…'
		return A
	def _append(A,event):
		B=json.dumps(event,ensure_ascii=False,default=str)
		with A._lock:
			try:
				with open(A._spill_path,'a',encoding='utf-8')as C:C.write(B+'\n')
			except Exception as D:_log(f"spill write failed: {D}");return
			A._pending+=1;A._trim_spill_locked();E=A._pending
		if E>=FLUSH_SIZE:A.flush(reason='size')
	def _trim_spill_locked(A):
		try:
			if os.path.getsize(A._spill_path)<=MAX_SPILL_BYTES:return
			with open(A._spill_path,'r',encoding='utf-8')as B:C=B.readlines()
			D=C[len(C)//2:]
			with open(A._spill_path,'w',encoding='utf-8')as B:B.writelines(D)
			_log(f"spill file trimmed, dropped {len(C)-len(D)} event(s)")
		except Exception as E:_log(f"spill trim failed: {E}")
	def _read_spill(C):
		A=[]
		try:
			if not os.path.isfile(C._spill_path):return A
			with C._lock:
				with open(C._spill_path,'r',encoding='utf-8')as F:G=F.readlines()
		except Exception as H:_log(f"spill read failed: {H}");return A
		I=datetime.now(timezone.utc).timestamp()-MAX_SPILL_AGE_DAYS*86400
		for B in G:
			B=B.strip()
			if not B:continue
			try:
				D=json.loads(B);E=str(D.get('occurredAt','')).replace('Z','+00:00')
				if E and datetime.fromisoformat(E).timestamp()<I:continue
				A.append(D)
			except Exception:continue
		return A
	def _drop_sent(A,sent_ids):
		with A._lock:
			try:
				if not os.path.isfile(A._spill_path):return
				with open(A._spill_path,'r',encoding='utf-8')as B:E=B.readlines()
				C=[]
				for D in E:
					try:
						if json.loads(D).get('eventId')in sent_ids:continue
					except Exception:continue
					C.append(D)
				with open(A._spill_path,'w',encoding='utf-8')as B:B.writelines(C)
			except Exception as F:_log(f"spill cleanup failed: {F}")
	def _send_once(B,reason):
		try:
			A=B._read_spill()
			if not A:return
			if B._transport.send(A):B._drop_sent({A.get('eventId')for A in A});_log(f"sent {len(A)} event(s) [{reason}]")
		except Exception as C:_log(f"send failed: {C}")
	def _arm_timer(A):
		if A._timer is not None:return
		try:from qgis.PyQt.QtCore import QTimer as B;A._timer=B();A._timer.setInterval(FLUSH_INTERVAL_MS);A._timer.timeout.connect(A._on_timer);A._timer.start()
		except Exception:A._timer=None
	def _on_timer(A):
		if A._pending:A.flush(reason='timer')
	def _stop_timer(A):
		try:
			if A._timer is not None:A._timer.stop();A._timer=None
		except Exception:pass
class NullAuditLog:
	session_id='';enabled=False
	def track(A,*B,**C):0
	def emitter(B,script='',run_id=''):
		def A(*A,**B):0
		return A
	def start(A):0
	def shutdown(A):0
	def flush(A,*B,**C):0