import os,builtins,time,uuid
from.bundle_loader import BundleLoader
BUNDLE_MAX_AGE_SECONDS=86400
class ScriptRunner:
	def __init__(A,local_dir='',bundle_path='',api_client=None,audit=None):
		C=bundle_path;B=audit;A._bundle_path=C;A._api_client=api_client;A._loader=BundleLoader(C)
		if B is None:from.audit import NullAuditLog as D;B=D()
		A._audit=B
	def run(B,script_name,globals_dict=None):E=globals_dict;D=script_name;A={}if E is None else dict(E);A.setdefault('run_script',B.run);F=A.get('gqg_run_id')or uuid.uuid4().hex;A['gqg_run_id']=F;A['gqg_audit']=B._audit.emitter(_base_name(D),F);B._ensure_bundle_loaded();A.setdefault('scripts',B._loader._scripts);C=B._resolve_bundle_name(D);print(f"[ScriptRunner] Priority 2 — bundle: {C!r}");A.setdefault('__file__',C);B._loader.run_script(C,A)
	def clear_bundle_cache(A):A._loader.purge()
	def _ensure_bundle_loaded(A):
		if A._loader.is_loaded:return
		B=not A._bundle_is_stale()
		if B:A._fetch_key()
		else:A._download_bundle()
		try:A._loader.ensure_loaded()
		except Exception as C:
			if not B:raise
			print(f"[ScriptRunner] Cached bundle unusable ({C}) — re-downloading.");A._loader.purge();A._download_bundle();A._loader.ensure_loaded()
	def _resolve_bundle_name(A,script_name):
		B=script_name
		for C in A._bundle_candidates(B):
			if A._loader.has_script(C):return C
		raise KeyError(f"[ScriptRunner] {B!r} not found in bundle. Tried: {A._bundle_candidates(B)}")
	@staticmethod
	def _bundle_candidates(script_name):A=script_name;B=_base_name(A);return[A,B+'.py.min',B+'.py']
	def _bundle_is_stale(A):
		try:C=os.path.getsize(A._bundle_path);B=time.time()-os.path.getmtime(A._bundle_path)
		except OSError:print('[ScriptRunner] No cached bundle — downloading.');return True
		if C==0:print('[ScriptRunner] Cached bundle is empty — downloading.');return True
		if B>=BUNDLE_MAX_AGE_SECONDS:print(f"[ScriptRunner] Cached bundle is {B/3600:.1f} h old — downloading.");return True
		print(f"[ScriptRunner] Using cached bundle ({B/3600:.1f} h old, {C:,} bytes): {A._bundle_path}");return False
	def _fetch_key(B):
		from.api_client.geo_q_guide_api_client.api.plugin_code_bundle import get_plugin_bundle_key as C;print('[ScriptRunner] Fetching bundle key from API …');A=B._api_client.call(C.sync_detailed)
		if A.status_code!=200:raise RuntimeError(f"[ScriptRunner] Bundle key fetch failed: HTTP {A.status_code}")
		B._loader.set_key(A.content)
	def _download_bundle(A):
		from.api_client.geo_q_guide_api_client.api.plugin_code_bundle import get_plugin_bundle as C;A._fetch_key();print(f"[ScriptRunner] Downloading bundle via API → {A._bundle_path!r} …");B=A._api_client.call(C.sync_detailed)
		if B.status_code!=200:raise RuntimeError(f"[ScriptRunner] Bundle download failed: HTTP {B.status_code}")
		with open(A._bundle_path,'wb')as D:D.write(B.content)
		A._loader._loaded=False;A._loader._scripts.clear();print('[ScriptRunner] Bundle downloaded successfully.')
def _base_name(script_name):
	A=script_name
	for B in('.min','.py'):
		if A.endswith(B):A=A[:-len(B)]
	return A