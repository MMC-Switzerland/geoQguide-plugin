from __future__ import annotations
import re
from qgis.PyQt.QtCore import QThread,pyqtSignal
from qgis.core import QgsSettings
PLUGINS_XML_URL='https://raw.githubusercontent.com/MMC-Switzerland/geoQguide-plugin/refs/heads/master/plugins.xml'
PLUGIN_KEY='plugins/geoQguide'
LATEST_VERSION_KEY=f"{PLUGIN_KEY}/latest_available_version"
def _parse_version(xml):A=re.search('<version>\\s*([^<\\s]+)\\s*</version>',xml);return A.group(1)if A else None
def _version_tuple(v):
	try:return tuple(int(A)for A in v.split('.'))
	except ValueError:return 0,
class _VersionCheckThread(QThread):
	update_available=pyqtSignal(str)
	def __init__(A,current_version):super().__init__();A._current=current_version
	def run(B):
		try:
			from urllib.request import urlopen as C
			with C(PLUGINS_XML_URL,timeout=10)as D:E=D.read().decode('utf-8',errors='replace')
			A=_parse_version(E)
			if A and _version_tuple(A)>_version_tuple(B._current):B.update_available.emit(A)
		except Exception:pass
def schedule_check(current_version,iface):A=_VersionCheckThread(current_version);A.update_available.connect(_record_update);iface._geoqguide_version_thread=A;A.start()
def _record_update(latest):QgsSettings().setValue(LATEST_VERSION_KEY,latest)
def _read_current_version():
	import configparser as B,os;C=os.path.dirname(os.path.abspath(__file__));A=B.ConfigParser()
	try:A.read(os.path.join(C,'metadata.txt'));return A.get('general','version',fallback='0')
	except Exception:return'0'
def get_available_update():
	B=QgsSettings();A=str(B.value(LATEST_VERSION_KEY,'')or'')
	if not A:return
	if _version_tuple(A)>_version_tuple(_read_current_version()):return A
	B.remove(LATEST_VERSION_KEY)