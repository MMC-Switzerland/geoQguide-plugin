"""Vendored third-party libraries shipped inside the plugin.

QGIS plugins cannot declare pip dependencies, so small, auth-critical
third-party modules are copied ("vendored") here and frozen.

Rules:
- Each library keeps its upstream LICENSE file next to the code and a
  provenance header listing any local modifications.
- Treat vendored code as FROZEN: upstream updates are pulled in
  deliberately, never automatically. (An update to `machineid` changes
  every user's device fingerprint and triggers the device-switch flow.)
- Feature-level dependencies (numpy, matplotlib, ...) do NOT belong
  here — those are handled by environment_check.py.
"""
